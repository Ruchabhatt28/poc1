using FranchiseeLogPOC.Client;
using FranchiseeLogPOC.Client.Services;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Authentication;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using MudBlazor.Services;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

var useDevAuth = builder.Configuration.GetValue<bool>("UseDevAuth");
var apiBase    = builder.Configuration["ApiBaseUrl"] ?? "https://localhost:7000/";

if (useDevAuth)
{
    // -----------------------------------------------------------------------
    // DEV MODE – no Entra ID required
    // Fake authenticated user; plain HttpClient (no bearer token).
    // -----------------------------------------------------------------------
    builder.Services.AddScoped<AuthenticationStateProvider, DevAuthStateProvider>();
    builder.Services.AddAuthorizationCore();

    builder.Services.AddHttpClient<IApiClient, ApiClient>(client =>
        client.BaseAddress = new Uri(apiBase));
}
else
{
    // -----------------------------------------------------------------------
    // PRODUCTION – Entra ID (Azure AD) MSAL authentication
    // Configure AzureAd section in wwwroot/appsettings.json first.
    // -----------------------------------------------------------------------
    builder.Services.AddMsalAuthentication(options =>
    {
        builder.Configuration.Bind("AzureAd", options.ProviderOptions.Authentication);
        options.ProviderOptions.DefaultAccessTokenScopes.Add(
            builder.Configuration["ApiScope"] ?? "api://YOUR-API-CLIENT-ID/FullPermission");
    });

    builder.Services.AddHttpClient<IApiClient, ApiClient>(client =>
            client.BaseAddress = new Uri(apiBase))
        .AddHttpMessageHandler<BaseAddressAuthorizationMessageHandler>();
}

// -----------------------------------------------------------------------
// MudBlazor
// -----------------------------------------------------------------------
builder.Services.AddMudServices();

// -----------------------------------------------------------------------
// Storage: IndexedDB for offline queue (single storage backend)
// -----------------------------------------------------------------------
builder.Services.AddScoped<IIndexedDbService, IndexedDbService>();

// -----------------------------------------------------------------------
// Application services
// -----------------------------------------------------------------------
builder.Services.AddScoped<ConnectivityService>();
builder.Services.AddScoped<OfflineSyncService>();
// Phase 2 features removed: Bluetooth + Push notifications
// Keep the app minimal: only connectivity + offline sync services are registered.

await builder.Build().RunAsync();
