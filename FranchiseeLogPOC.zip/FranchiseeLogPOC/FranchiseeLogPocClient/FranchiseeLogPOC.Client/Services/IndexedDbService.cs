using Microsoft.JSInterop;
using System.Text.Json;

namespace FranchiseeLogPOC.Client.Services;

public class IndexedDbService : IIndexedDbService
{
    private readonly IJSRuntime _js;

    // Blazor's JSRuntime serialises C# objects to JS as camelCase.
    // We must use the same options when deserialising the round-tripped JSON so
    // that property names match (e.g. "activityType" → ActivityType).
    private static readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
    };

    public IndexedDbService(IJSRuntime js) => _js = js;

    public async Task<T?> GetItemAsync<T>(string key)
    {
        // JS returns JSON.stringify(value) – a string – or null when key is absent.
        // Using string avoids the struct (JsonElement) null-cast crash.
        var json = await _js.InvokeAsync<string?>("indexedDbInterop.getItem", key);
        if (string.IsNullOrEmpty(json)) return default;
        return JsonSerializer.Deserialize<T>(json, _jsonOptions);
    }

    public async Task SetItemAsync<T>(string key, T item)
    {
        await _js.InvokeVoidAsync("indexedDbInterop.setItem", key, item);
    }
}
