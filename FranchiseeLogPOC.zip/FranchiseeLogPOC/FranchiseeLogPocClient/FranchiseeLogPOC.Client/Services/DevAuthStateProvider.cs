using Microsoft.AspNetCore.Components.Authorization;
using System.Security.Claims;

namespace FranchiseeLogPOC.Client.Services;

/// <summary>
/// Development-only authentication state provider.
/// Returns a pre-authenticated fake user so the whole UI renders
/// without needing an Entra ID app registration.
///
/// Activated when UseDevAuth=true in wwwroot/appsettings.Development.json.
/// Set UseDevAuth=false once Entra is configured – MSAL takes over automatically.
/// </summary>
public class DevAuthStateProvider : AuthenticationStateProvider
{
    private AuthenticationState _currentState = BuildState();

    public override Task<AuthenticationState> GetAuthenticationStateAsync()
        => Task.FromResult(_currentState);

    public Task SignOutAsync()
    {
        // Set an empty principal (not authenticated) and notify consumers.
        _currentState = new AuthenticationState(new ClaimsPrincipal());
        NotifyAuthenticationStateChanged(Task.FromResult(_currentState));
        return Task.CompletedTask;
    }

    public Task SignInAsync()
    {
        _currentState = BuildState();
        NotifyAuthenticationStateChanged(Task.FromResult(_currentState));
        return Task.CompletedTask;
    }

    private static AuthenticationState BuildState()
    {
        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, "dev-user-id"),
            new Claim(ClaimTypes.Name,           "Dev User"),
            new Claim(ClaimTypes.Email,          "devuser@qualified.domain.name"),
            new Claim("preferred_username",      "devuser@qualified.domain.name"),
        };

        var identity = new ClaimsIdentity(claims, authenticationType: "DevAuth");
        return new AuthenticationState(new ClaimsPrincipal(identity));
    }
}
