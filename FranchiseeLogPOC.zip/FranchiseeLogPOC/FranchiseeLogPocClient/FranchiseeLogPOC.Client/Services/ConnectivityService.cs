using Microsoft.JSInterop;
using System.Linq;
using System.Threading.Tasks;

namespace FranchiseeLogPOC.Client.Services;

/// <summary>
/// Tracks browser online/offline state and fires events when connectivity changes.
/// Uses JS interop to tap into the browser Navigator API.
/// </summary>
public class ConnectivityService : IAsyncDisposable
{
    private readonly IJSRuntime _js;
    private DotNetObjectReference<ConnectivityService>? _dotNetRef;
    private bool _isOnline = true;

    public bool IsOnline => _isOnline;

    // Use async event handlers so subscribers can await work (e.g. FlushAsync).
    public event Func<bool, Task>? ConnectivityChanged;

    public ConnectivityService(IJSRuntime js)
    {
        _js = js;
    }

    public async Task InitialiseAsync()
    {
        _dotNetRef = DotNetObjectReference.Create(this);
        _isOnline = await _js.InvokeAsync<bool>("connectivityInterop.init", _dotNetRef);
    }

    [JSInvokable]
    public async Task OnConnectivityChanged(bool isOnline)
    {
        _isOnline = isOnline;

        var handlers = ConnectivityChanged;
        if (handlers is null) return;

        // Invoke all subscribers and wait for them to complete.
        var invocationList = handlers.GetInvocationList()
            .Cast<Func<bool, Task>>()
            .Select(h => h(isOnline));

        try
        {
            await Task.WhenAll(invocationList);
        }
        catch
        {
            // Swallow here – subscribers should log their own errors.
        }
    }

    public async ValueTask DisposeAsync()
    {
        await _js.InvokeVoidAsync("connectivityInterop.dispose");
        _dotNetRef?.Dispose();
    }
}
