using FranchiseeLogPOC.Client.Models;

namespace FranchiseeLogPOC.Client.Services;

/// <summary>
/// Manages the offline activity-log queue.
///
/// Design principles (bug-free):
///   1. ONE code path: EnqueueAndTrySyncAsync always persists to IndexedDB first,
///      then flushes if online. No separate "online" vs "offline" paths.
///   2. Three-phase locking in FlushAsync: LOCK→snapshot, HTTP (no lock), LOCK→merge.
///      The lock is NEVER held during network I/O.
///   3. Concurrent flush guard (Interlocked): only one FlushAsync runs at a time.
///      Timer and connectivity events both try to flush; the second one is a no-op.
///   4. GetPendingCountAsync only counts PendingSync — never Syncing — so the timer
///      never re-fires on items that are already in-flight.
///   5. No "add if not found" fallback in result-merging. Missing = skip, never duplicate.
///   6. PullServerEntriesAsync merges by RequestId; only adds if genuinely absent.
/// </summary>
public class OfflineSyncService : IDisposable
{
    // Queue key namespaced per user – no bleed between users on the same device.
    private string QueueKey => $"offline_activity_queue_{_userId}";
    private const int MaxRetries = 5;
    private static readonly TimeSpan RetryInterval = TimeSpan.FromSeconds(30);

    private readonly IIndexedDbService _storage;
    private readonly IApiClient _api;
    private readonly ConnectivityService _connectivity;
    private readonly ILogger<OfflineSyncService> _logger;
    private readonly Timer _retryTimer;

    // Lock guards queue reads/writes ONLY – never held during network I/O.
    private readonly SemaphoreSlim _queueLock = new(1, 1);

    // Interlocked flag: only one FlushAsync may run at a time.
    // Timer fires + connectivity events can both call Flush; the second call is a no-op.
    private int _flushInProgress;

    private string _userId = "anonymous";

    public event Action? QueueChanged;

    public void SetUser(string userId) =>
        _userId = string.IsNullOrWhiteSpace(userId) ? "anonymous" : userId;

    public OfflineSyncService(
        IIndexedDbService storage,
        IApiClient api,
        ConnectivityService connectivity,
        ILogger<OfflineSyncService> logger)
    {
        _storage      = storage;
        _api          = api;
        _connectivity = connectivity;
        _logger       = logger;

        _connectivity.ConnectivityChanged += async online =>
        {
            if (online)
            {
                _logger.LogInformation("Connectivity restored – flushing and pulling.");
                await FlushAsync();
                await PullServerEntriesAsync();
            }
        };

        // Polling fallback – retries PendingSync items every 30 s.
        // First attempt after 5 s so an entry queued while offline gets a fast retry.
        _retryTimer = new Timer(async _ =>
        {
            if (_connectivity.IsOnline && await GetPendingCountAsync() > 0)
            {
                _logger.LogInformation("Retry timer – flushing pending items.");
                await FlushAsync();
            }
        }, null, TimeSpan.FromSeconds(5), RetryInterval);
    }

    // -------------------------------------------------------------------------
    // Public API
    // -------------------------------------------------------------------------

    /// <summary>
    /// Single entry-point for saving an entry.
    /// Always persists to IndexedDB first (offline-safe), then flushes if online.
    /// Returns true if the entry was accepted by the server in this call.
    /// </summary>
    public async Task<bool> TrySaveNowAsync(ActivityLogEntry entry)
    {
        // --- Phase 1: Persist to local queue atomically. ---
        entry.SyncState  = SyncState.PendingSync;
        entry.RetryCount = 0;
        entry.SyncError  = null;

        await _queueLock.WaitAsync();
        try
        {
            var queue = await GetQueueInternalAsync();
            // Guard: never add a duplicate RequestId.
            if (!queue.Any(e => e.RequestId == entry.RequestId))
                queue.Add(entry);
            await SaveQueueAsync(queue);
        }
        finally
        {
            _queueLock.Release();
            QueueChanged?.Invoke();
        }

        // --- Phase 2: If online, attempt an immediate flush. ---
        if (!_connectivity.IsOnline)
            return false;

        await FlushAsync();

        // Return true only when this specific entry was accepted.
        var snapshot = await GetQueueInternalAsync();
        return snapshot.FirstOrDefault(e => e.RequestId == entry.RequestId)
                       ?.SyncState == SyncState.Synced;
    }

    /// <summary>Offline path – persists and queues for later retry.</summary>
    public async Task EnqueueAsync(ActivityLogEntry entry) =>
        await TrySaveNowAsync(entry);   // delegates to single code path

    public async Task<IReadOnlyList<ActivityLogEntry>> GetQueueAsync() =>
        await GetQueueInternalAsync();

    /// <summary>
    /// Only counts PendingSync (not Syncing). This prevents the retry timer from
    /// firing a second flush on entries that are already in-flight.
    /// </summary>
    public async Task<int> GetPendingCountAsync()
    {
        var q = await GetQueueInternalAsync();
        return q.Count(e => e.SyncState == SyncState.PendingSync);
    }

    // -------------------------------------------------------------------------
    // FlushAsync – three-phase: snapshot (lock) | HTTP (no lock) | merge (lock)
    // -------------------------------------------------------------------------
    public async Task FlushAsync()
    {
        // Only one flush at a time. Timer + connectivity events both call this;
        // if one is already running the second call returns immediately.
        if (Interlocked.CompareExchange(ref _flushInProgress, 1, 0) != 0)
        {
            _logger.LogDebug("FlushAsync skipped – another flush is already running.");
            return;
        }

        try
        {
            // ---- Phase 1: acquire snapshot of pending items (lock held ≪ 1 ms). ----
            List<ActivityLogEntry> pending;
            await _queueLock.WaitAsync();
            try
            {
                var queue = await GetQueueInternalAsync();

                // Heal orphaned Syncing entries (app reloaded / crashed mid-flight).
                var healed = false;
                foreach (var stuck in queue.Where(e => e.SyncState == SyncState.Syncing))
                {
                    stuck.SyncState = SyncState.PendingSync;
                    healed = true;
                }
                if (healed) await SaveQueueAsync(queue);

                pending = queue
                    .Where(e => e.SyncState == SyncState.PendingSync && e.RetryCount < MaxRetries)
                    .ToList();

                if (pending.Count == 0)
                    return;  // nothing to do; lock released in finally

                // Mark in-flight so UI badge shows "syncing".
                foreach (var item in pending)
                    item.SyncState = SyncState.Syncing;

                await SaveQueueAsync(queue);
                QueueChanged?.Invoke();
            }
            finally
            {
                _queueLock.Release();
            }

            // ---- Phase 2: HTTP call – lock is NOT held. ----
            _logger.LogInformation("Flushing {Count} entries.", pending.Count);
            SyncBatchResponse? response = null;
            Exception? httpError = null;
            try
            {
                response = await _api.SyncBatchAsync(new SyncBatchRequest
                {
                    Items = pending.Select(e => new SyncItem
                    {
                        RequestId          = e.RequestId,
                        FranchiseeId       = e.FranchiseeId,
                        ActivityType       = e.ActivityType,
                        Notes              = e.Notes,
                        PhReading          = e.PhReading,
                        TemperatureCelsius = e.TemperatureCelsius,
                        OccurredAt         = e.OccurredAt
                    }).ToList()
                });

                if (response is null)
                    _logger.LogWarning("SyncBatchAsync returned null response (deserialization failed?).");
            }
            catch (Exception ex)
            {
                httpError = ex;
                _logger.LogWarning(ex, "Sync batch HTTP call failed: {Message}", ex.Message);
            }

            // ---- Phase 3: merge results back into queue (lock held ≪ 1 ms). ----
            await _queueLock.WaitAsync();
            try
            {
                // Re-read the full queue so we don't lose items added while HTTP was in flight.
                var queue = await GetQueueInternalAsync();

                if (response is not null)
                {
                    foreach (var result in response.Results)
                    {
                        var item = queue.FirstOrDefault(e => e.RequestId == result.RequestId);
                        if (item is not null)
                        {
                            item.SyncState = SyncState.Synced;
                            item.ServerId  = result.ServerId;
                            item.SyncError = null;
                        }
                        else
                        {
                            _logger.LogWarning(
                                "Phase 3: could not find RequestId {RequestId} in queue – item may have been removed.",
                                result.RequestId);
                        }
                    }
                }
                else if (httpError is HttpRequestException)
                {
                    // Network error – reset to PendingSync, keep RetryCount at 0
                    // so items retry indefinitely (not penalised for connectivity loss).
                    foreach (var item in pending)
                    {
                        var q = queue.FirstOrDefault(e => e.RequestId == item.RequestId);
                        if (q is not null)
                        {
                            q.SyncState  = SyncState.PendingSync;
                            q.RetryCount = 0;
                            q.SyncError  = "Offline – retrying…";
                        }
                    }
                }
                else if (httpError is not null)
                {
                    // Server error – increment retry; mark Failed after MaxRetries.
                    foreach (var item in pending)
                    {
                        var q = queue.FirstOrDefault(e => e.RequestId == item.RequestId);
                        if (q is not null)
                        {
                            q.RetryCount++;
                            q.SyncError  = httpError.Message;
                            q.SyncState  = q.RetryCount >= MaxRetries
                                ? SyncState.Failed
                                : SyncState.PendingSync;
                            if (q.SyncState == SyncState.Failed)
                                _logger.LogError("Entry {RequestId} exhausted retries.", item.RequestId);
                        }
                    }
                }
                else
                {
                    // Null response – reset so they'll retry.
                    _logger.LogWarning("Null response with no httpError – resetting {Count} items to PendingSync.", pending.Count);
                    foreach (var item in pending)
                    {
                        var q = queue.FirstOrDefault(e => e.RequestId == item.RequestId);
                        if (q is not null)
                        {
                            q.SyncState = SyncState.PendingSync;
                            q.SyncError = "Server did not respond";
                        }
                    }
                }

                // Save the full queue – no auto-pruning so entries are never
                // silently removed. The UI shows all entries the user has ever
                // submitted on this device, which is the correct POC behaviour.
                await SaveQueueAsync(queue);
            }
            finally
            {
                _queueLock.Release();
                QueueChanged?.Invoke();
            }
        }
        finally
        {
            Interlocked.Exchange(ref _flushInProgress, 0);
        }
    }

    // -------------------------------------------------------------------------
    // PullServerEntriesAsync – fetch all server records and merge into local queue.
    // Always does a full pull (no incremental watermark) so the local queue
    // always reflects everything on the server for this franchisee.
    // Two-phase: HTTP (no lock) | merge (lock).
    // -------------------------------------------------------------------------
    public async Task PullServerEntriesAsync()
    {
        if (!_connectivity.IsOnline) return;

        // ---- Phase 1: HTTP call – no lock held. ----
        List<ActivityLogDto>? serverList;
        try
        {
            // Pass null for 'since' to always get the full server history.
            serverList = await _api.GetActivityLogsAsync(_userId, since: null);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "PullServerEntries GET failed: {Message}", ex.Message);
            return;
        }
        if (serverList is null || serverList.Count == 0) return;

        // ---- Phase 2: merge under lock. ----
        await _queueLock.WaitAsync();
        try
        {
            var queue = await GetQueueInternalAsync();

            foreach (var dto in serverList)
            {
                var existing = queue.FirstOrDefault(q => q.RequestId == dto.RequestId);
                if (existing is not null)
                {
                    existing.ServerId  = dto.Id;
                    existing.SyncState = SyncState.Synced;
                    existing.SyncError = null;
                }
                else
                {
                    // Record missing locally (e.g. was pruned, or created on another device).
                    queue.Add(new ActivityLogEntry
                    {
                        RequestId          = dto.RequestId,
                        FranchiseeId       = dto.FranchiseeId,
                        ActivityType       = dto.ActivityType,
                        Notes              = dto.Notes,
                        PhReading          = dto.PhReading,
                        TemperatureCelsius = dto.TemperatureCelsius,
                        OccurredAt         = dto.OccurredAt,
                        SyncState          = SyncState.Synced,
                        ServerId           = dto.Id
                    });
                }
            }

            await SaveQueueAsync(queue);
        }
        finally
        {
            _queueLock.Release();
            QueueChanged?.Invoke();
        }
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------
    public void Dispose() => _retryTimer.Dispose();

    private async Task<List<ActivityLogEntry>> GetQueueInternalAsync()
    {
        try
        {
            return await _storage.GetItemAsync<List<ActivityLogEntry>>(QueueKey) ?? new();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "IndexedDB GetItem failed for key {Key}", QueueKey);
            return new();
        }
    }

    private Task SaveQueueAsync(IEnumerable<ActivityLogEntry> queue) =>
        _storage.SetItemAsync(QueueKey, queue.ToList());
}
