using System.Threading.Tasks;

namespace FranchiseeLogPOC.Client.Services
{
    public interface IIndexedDbService
    {
        Task<T?> GetItemAsync<T>(string key);
        Task SetItemAsync<T>(string key, T item);
    }
}
