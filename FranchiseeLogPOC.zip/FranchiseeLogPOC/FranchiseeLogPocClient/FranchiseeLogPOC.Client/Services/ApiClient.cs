using FranchiseeLogPOC.Client.Models;
using System.Net.Http.Json;

namespace FranchiseeLogPOC.Client.Services;

/// <summary>API client contract for dependency injection / testing.</summary>
public interface IApiClient
{
    Task<SyncBatchResponse?> SyncBatchAsync(SyncBatchRequest request, CancellationToken ct = default);
    Task<List<ActivityLogDto>?> GetActivityLogsAsync(string? franchiseeId = null, DateTimeOffset? since = null, CancellationToken ct = default);
}

public class ApiClient(HttpClient http) : IApiClient
{
    public async Task<SyncBatchResponse?> SyncBatchAsync(SyncBatchRequest request, CancellationToken ct = default)
    {
        var response = await http.PostAsJsonAsync("api/activitylogs/sync", request, ct);
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<SyncBatchResponse>(cancellationToken: ct);
    }

    public async Task<List<ActivityLogDto>?> GetActivityLogsAsync(string? franchiseeId = null, DateTimeOffset? since = null, CancellationToken ct = default)
    {
        var url = "api/activitylogs";
        var parts = new List<string>();
        if (!string.IsNullOrWhiteSpace(franchiseeId)) parts.Add($"franchiseeId={Uri.EscapeDataString(franchiseeId)}");
        if (since.HasValue) parts.Add($"since={Uri.EscapeDataString(since.Value.ToString("o"))}");
        if (parts.Count > 0) url += "?" + string.Join("&", parts);

        var resp = await http.GetAsync(url, ct);
        if (!resp.IsSuccessStatusCode) return null;
        return await resp.Content.ReadFromJsonAsync<List<ActivityLogDto>>(cancellationToken: ct);
    }
}

// DTO used by the client to fetch server-side entries
public class ActivityLogDto
{
    public int Id { get; set; }
    public Guid RequestId { get; set; }
    public string FranchiseeId { get; set; } = string.Empty;
    public string ActivityType { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public double? PhReading { get; set; }
    public double? TemperatureCelsius { get; set; }
    public DateTimeOffset OccurredAt { get; set; }
    public DateTimeOffset SyncedAt { get; set; }
}

// ---- Shared request/response DTOs ----
public class SyncBatchRequest
{
    public List<SyncItem> Items { get; set; } = new();
}

public class SyncItem
{
    public Guid RequestId { get; set; }
    public string FranchiseeId { get; set; } = string.Empty;
    public string ActivityType { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public double? PhReading { get; set; }
    public double? TemperatureCelsius { get; set; }
    public DateTimeOffset OccurredAt { get; set; }
}

public class SyncBatchResponse
{
    public List<SyncItemResult> Results { get; set; } = new();
    public int Accepted { get; set; }
    public int Duplicate { get; set; }
}

public class SyncItemResult
{
    public Guid RequestId { get; set; }
    public bool WasDuplicate { get; set; }
    public int ServerId { get; set; }
}


