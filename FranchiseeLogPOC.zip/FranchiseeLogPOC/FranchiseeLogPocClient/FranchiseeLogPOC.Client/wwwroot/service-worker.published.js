// Standard Blazor WASM offline-capable service worker.
// Used only in published builds (dotnet publish). In development the plain
// service-worker.js is used instead and intentionally does nothing so hot-reload
// still works without stale cache issues.
//
// How offline works:
//   Install  – pre-caches every asset listed in service-worker-assets.js (generated
//               by the Blazor build: all DLLs, WASM, JS, CSS, HTML, images).
//   Activate – removes stale cache buckets from previous deployments.
//   Fetch    – serves from cache first; falls back to network for API calls and
//               any asset not yet cached.
//
// API calls (/api/*) are intentionally NOT cached – they always go to the network
// (or fail gracefully in OfflineSyncService when offline).

self.importScripts('./service-worker-assets.js');

self.addEventListener('install',  event => event.waitUntil(onInstall(event)));
self.addEventListener('activate', event => event.waitUntil(onActivate(event)));
self.addEventListener('fetch',    event => event.respondWith(onFetch(event)));

const cacheNamePrefix = 'franchisee-log-cache-';
const cacheName       = `${cacheNamePrefix}${self.assetsManifest.version}`;

// Asset types to pre-cache so the app shell loads fully offline.
const offlineAssetsInclude = [
    /\.dll$/, /\.pdb$/, /\.wasm/,
    /\.html$/, /\.js$/, /\.json$/,
    /\.css$/, /\.woff2?$/, /\.ttf$/, /\.eot$/,
    /\.png$/, /\.jpe?g$/, /\.gif$/, /\.ico$/, /\.svg$/,
    /\.blat$/, /\.dat$/
];
// Never cache the service worker itself.
const offlineAssetsExclude = [ /^service-worker\.js$/ ];

// Adjust if the app is hosted under a sub-path (e.g. /app/).
const base    = '/';
const baseUrl = new URL(base, self.origin);

async function onInstall(event) {
    console.info('[SW] Install – caching app shell assets.');
    const assetsRequests = self.assetsManifest.assets
        .filter(a =>  offlineAssetsInclude.some(p => p.test(a.url)))
        .filter(a => !offlineAssetsExclude.some(p => p.test(a.url)))
        .map(a => new Request(new URL(a.url, baseUrl).href, {
            integrity: a.hash,
            cache: 'no-cache'
        }));

    const cache = await caches.open(cacheName);
    await cache.addAll(assetsRequests);

    // Activate immediately so users don't have to close all tabs.
    await self.skipWaiting();
}

async function onActivate(event) {
    console.info('[SW] Activate – pruning old caches.');
    const keys = await caches.keys();
    await Promise.all(
        keys
            .filter(k => k.startsWith(cacheNamePrefix) && k !== cacheName)
            .map(k => caches.delete(k))
    );
    // Take control of all open tabs immediately.
    await self.clients.claim();
}

async function onFetch(event) {
    // Never intercept API calls – let them go to the network (or fail).
    // OfflineSyncService handles the offline-queue flow at the app level.
    const url = new URL(event.request.url);
    if (url.pathname.startsWith('/api/')) {
        return fetch(event.request);
    }

    if (event.request.method !== 'GET') {
        return fetch(event.request);
    }

    // Navigation requests (F5, address bar, close+reopen) → serve index.html
    // from cache so the Blazor app shell always loads offline.
    const shouldServeIndexHtml = event.request.mode === 'navigate';
    const cacheKey = shouldServeIndexHtml ? 'index.html' : event.request;

    const cache          = await caches.open(cacheName);
    const cachedResponse = await cache.match(cacheKey);

    if (cachedResponse) return cachedResponse;

    // Not in cache (new asset after install) – try network, cache for next time.
    try {
        const networkResponse = await fetch(event.request);
        if (networkResponse.ok && !shouldServeIndexHtml) {
            cache.put(event.request, networkResponse.clone());
        }
        return networkResponse;
    } catch {
        // Truly offline and asset not cached – return a minimal offline response
        // so the Blazor error UI can at least render something.
        return new Response('Offline – resource not available', {
            status: 503,
            headers: { 'Content-Type': 'text/plain' }
        });
    }
}
