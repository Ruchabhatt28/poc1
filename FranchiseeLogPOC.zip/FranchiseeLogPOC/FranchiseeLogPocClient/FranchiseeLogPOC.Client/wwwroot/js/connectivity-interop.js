// ============================================================================
// connectivity-interop.js
// Bridges browser online/offline events to Blazor via JS interop.
// ============================================================================

window.connectivityInterop = (() => {
    let dotNetRef = null;

    function handleOnline() {
        if (dotNetRef) dotNetRef.invokeMethodAsync('OnConnectivityChanged', true);
    }

    function handleOffline() {
        if (dotNetRef) dotNetRef.invokeMethodAsync('OnConnectivityChanged', false);
    }

    return {
        /**
         * Initialise connectivity monitoring.
         * Returns the current online state immediately.
         */
        init(ref) {
            dotNetRef = ref;
            window.addEventListener('online', handleOnline);
            window.addEventListener('offline', handleOffline);
            return navigator.onLine;
        },

        dispose() {
            window.removeEventListener('online', handleOnline);
            window.removeEventListener('offline', handleOffline);
            dotNetRef = null;
        }
    };
})();
