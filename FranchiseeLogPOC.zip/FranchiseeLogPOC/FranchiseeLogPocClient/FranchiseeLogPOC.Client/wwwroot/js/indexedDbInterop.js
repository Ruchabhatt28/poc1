const indexedDbInterop = (function () {
    const DB_NAME = 'FranchiseeLogPOC_DB';
    const STORE = 'kv';

    function openDb() {
        return new Promise((resolve, reject) => {
            const req = indexedDB.open(DB_NAME, 1);
            let handled = false;

            req.onupgradeneeded = function (ev) {
                const db = ev.target.result;
                if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
            };

            req.onsuccess = () => {
                const db = req.result;
                // Defensive: if the object store is missing (possible with
                // origin/port changes or corrupted DB), delete and recreate DB.
                if (!db.objectStoreNames.contains(STORE)) {
                    db.close();
                    // delete and reopen (this will clear any existing DB data)
                    const delReq = indexedDB.deleteDatabase(DB_NAME);
                    delReq.onsuccess = () => {
                        // reopen once deleted
                        const r2 = indexedDB.open(DB_NAME, 1);
                        r2.onupgradeneeded = function (ev2) {
                            const db2 = ev2.target.result;
                            if (!db2.objectStoreNames.contains(STORE)) db2.createObjectStore(STORE);
                        };
                        r2.onsuccess = () => resolve(r2.result);
                        r2.onerror = () => reject(r2.error);
                    };
                    delReq.onerror = () => reject(delReq.error);
                    return;
                }

                if (!handled) {
                    handled = true;
                    resolve(db);
                }
            };

            req.onerror = () => {
                if (!handled) reject(req.error);
            };
        });
    }

    async function getItem(key) {
        const db = await openDb();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(STORE, 'readonly');
            const store = tx.objectStore(STORE);
            const r = store.get(key);
            r.onsuccess = () => {
                // Return JSON string (or null) so C# can deserialise without
                // hitting value-type null-cast exceptions in JSInterop.
                const val = r.result;
                resolve(val === undefined || val === null ? null : JSON.stringify(val));
            };
            r.onerror = () => reject(r.error);
        });
    }

    async function setItem(key, value) {
        const db = await openDb();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(STORE, 'readwrite');
            const store = tx.objectStore(STORE);
            const r = store.put(value, key);
            r.onsuccess = () => resolve(true);
            r.onerror = () => reject(r.error);
        });
    }

    return { getItem, setItem };
})();

window.indexedDbInterop = indexedDbInterop;
