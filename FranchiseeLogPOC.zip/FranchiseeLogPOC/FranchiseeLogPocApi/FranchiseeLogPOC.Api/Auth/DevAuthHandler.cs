using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;
using System.Security.Claims;
using System.Text.Encodings.Web;

namespace FranchiseeLogPOC.Api.Auth;

/// <summary>
/// Development-only authentication handler.
/// Activated when UseDevAuth=true in appsettings.Development.json.
/// Returns a fake authenticated user so [Authorize] passes without Entra ID.
/// Remove nothing – just set UseDevAuth=false (or omit it) once Entra is configured.
/// </summary>
public class DevAuthHandler(
    IOptionsMonitor<AuthenticationSchemeOptions> options,
    ILoggerFactory logger,
    UrlEncoder encoder)
    : AuthenticationHandler<AuthenticationSchemeOptions>(options, logger, encoder)
{
    public const string SchemeName = "DevAuth";

    protected override Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, "dev-user-id"),
            new Claim(ClaimTypes.Name,           "Dev User"),
            new Claim(ClaimTypes.Email,          "devuser@qualified.domain.name"),
            new Claim("preferred_username",      "devuser@qualified.domain.name"),
        };

        var identity  = new ClaimsIdentity(claims, SchemeName);
        var principal = new ClaimsPrincipal(identity);
        var ticket    = new AuthenticationTicket(principal, SchemeName);

        return Task.FromResult(AuthenticateResult.Success(ticket));
    }
}
