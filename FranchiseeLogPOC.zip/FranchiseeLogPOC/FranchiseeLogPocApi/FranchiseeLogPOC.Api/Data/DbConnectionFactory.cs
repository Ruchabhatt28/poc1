using Microsoft.Data.SqlClient;
using System.Data;

namespace FranchiseeLogPOC.Api.Data;

/// <summary>
/// Creates open-ready SQL connections from the configured connection string.
/// Inject this into controllers; each controller opens/closes its own connection
/// per request (Dapper handles the lifetime via using statement).
/// </summary>
public class DbConnectionFactory(IConfiguration configuration)
{
    private readonly string _connectionString =
        configuration.GetConnectionString("DefaultConnection")
        ?? throw new InvalidOperationException("DefaultConnection is not configured.");

    public IDbConnection CreateConnection() => new SqlConnection(_connectionString);
}
