namespace FranchiseeLogPOC.Api.Models;

/// <summary>
/// Used when the client pushes a batch of offline-queued activity logs.
/// The server processes each item idempotently via RequestId.
/// </summary>
public class SyncBatchRequest
{
    public List<ActivityLogSyncItem> Items { get; set; } = new();
}

public class ActivityLogSyncItem
{
    public Guid RequestId { get; set; }
    public string FranchiseeId { get; set; } = string.Empty;
    public string ActivityType { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public double? PhReading { get; set; }
    public double? TemperatureCelsius { get; set; }
    public DateTimeOffset OccurredAt { get; set; }
}

public class SyncBatchResponse
{
    public List<SyncItemResult> Results { get; set; } = new();
    public int Accepted { get; set; }
    public int Duplicate { get; set; }
}

public class SyncItemResult
{
    public Guid RequestId { get; set; }
    public bool WasDuplicate { get; set; }
    public int ServerId { get; set; }
}
