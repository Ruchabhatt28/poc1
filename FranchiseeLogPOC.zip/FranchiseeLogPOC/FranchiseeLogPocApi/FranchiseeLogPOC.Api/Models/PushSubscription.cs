namespace FranchiseeLogPOC.Api.Models;

/// <summary>
/// Stores a Web Push subscription endpoint + keys so the server can push
/// notifications to a franchisee's browser / Android PWA.
/// </summary>
public class PushSubscription
{
    public int Id { get; set; }
    public string FranchiseeId { get; set; } = string.Empty;
    public string Endpoint { get; set; } = string.Empty;
    public string P256DhKey { get; set; } = string.Empty;   // base64url client public key
    public string AuthKey { get; set; } = string.Empty;      // base64url auth secret
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
}
