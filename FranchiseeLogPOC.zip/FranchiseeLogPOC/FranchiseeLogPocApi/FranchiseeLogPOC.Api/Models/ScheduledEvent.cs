namespace FranchiseeLogPOC.Api.Models;

public class ScheduledEvent
{
    public int Id { get; set; }
    public string FranchiseeId { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public DateTimeOffset ScheduledAt { get; set; }
    public bool IsRecurring { get; set; }
    public string? RecurrenceRule { get; set; }   // iCal RRULE string, e.g. "FREQ=DAILY;INTERVAL=1"
    public int NotifyMinutesBefore { get; set; } = 15;
    public bool NotificationSent { get; set; }
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
}
