namespace FranchiseeLogPOC.Api.Models;

public class ActivityLog
{
    public int Id { get; set; }

    /// <summary>
    /// Client-generated GUID used for idempotent sync. If a record with this
    /// RequestId already exists the server returns the existing record (no duplicate).
    /// </summary>
    public Guid RequestId { get; set; }

    public string FranchiseeId { get; set; } = string.Empty;
    public string ActivityType { get; set; } = string.Empty;   // e.g. "WaterTest", "Cleaning"
    public string Notes { get; set; } = string.Empty;

    // Sensor readings (Phase 2 – supplied by Bluetooth devices)
    public double? PhReading { get; set; }
    public double? TemperatureCelsius { get; set; }

    public DateTimeOffset OccurredAt { get; set; }   // timestamp from the device
    public DateTimeOffset SyncedAt { get; set; }     // timestamp when API received it

    public SyncStatus SyncStatus { get; set; } = SyncStatus.Synced;
}

public enum SyncStatus
{
    Synced = 0,
    PendingReview = 1,
    Conflict = 2
}
