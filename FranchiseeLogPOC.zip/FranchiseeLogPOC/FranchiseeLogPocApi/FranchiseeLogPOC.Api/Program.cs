using FranchiseeLogPOC.Api.Auth;
using FranchiseeLogPOC.Api.Data;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Identity.Web;

var builder = WebApplication.CreateBuilder(args);

// -----------------------------------------------------------------------
// Authentication
// UseDevAuth=true  → fake local user, no Entra ID required (dev only)
// UseDevAuth=false → real Entra ID JWT Bearer (production path)
// -----------------------------------------------------------------------
var useDevAuth = builder.Configuration.GetValue<bool>("UseDevAuth");

if (useDevAuth)
{
    builder.Services.AddAuthentication(DevAuthHandler.SchemeName)
        .AddScheme<Microsoft.AspNetCore.Authentication.AuthenticationSchemeOptions,
                   DevAuthHandler>(DevAuthHandler.SchemeName, null);
}
else
{
    builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
        .AddMicrosoftIdentityWebApi(builder.Configuration.GetSection("AzureAd"));
}

// -----------------------------------------------------------------------
// Dapper – SQL Server connection factory
// -----------------------------------------------------------------------
builder.Services.AddSingleton<DbConnectionFactory>();

// -----------------------------------------------------------------------
// Controllers + OpenAPI
// -----------------------------------------------------------------------
builder.Services.AddControllers();
builder.Services.AddOpenApi();

// -----------------------------------------------------------------------
// CORS
// Dev (UseDevAuth=true): allow any origin so both localhost and LAN IP
//   work without reconfiguring on each machine / port change.
// Production: restrict to the configured ClientOrigin.
// -----------------------------------------------------------------------
builder.Services.AddCors(o => o.AddPolicy("BlazorClient", p =>
{
    if (useDevAuth)
        p.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod();
    else
    {
        var clientOrigin = builder.Configuration["ClientOrigin"] ?? "https://localhost:7001";
        p.WithOrigins(clientOrigin).AllowAnyHeader().AllowAnyMethod();
    }
}));

var app = builder.Build();

if (app.Environment.IsDevelopment())
    app.MapOpenApi();

// Only redirect to HTTPS when it is actually configured (avoids 307 loops
// and warning noise when running HTTP-only during local / LAN dev).
if (!app.Environment.IsDevelopment())
    app.UseHttpsRedirection();

app.UseCors("BlazorClient");
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();

app.Run();
