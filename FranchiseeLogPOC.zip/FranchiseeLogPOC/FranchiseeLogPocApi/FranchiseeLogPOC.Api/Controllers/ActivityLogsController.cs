using Dapper;
using Microsoft.Data.SqlClient;
using FranchiseeLogPOC.Api.Data;
using FranchiseeLogPOC.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FranchiseeLogPOC.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ActivityLogsController(DbConnectionFactory dbFactory, ILogger<ActivityLogsController> logger)
    : ControllerBase
{
    // -----------------------------------------------------------------------
    // GET api/activitylogs?franchiseeId=xxx
    // -----------------------------------------------------------------------
    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] string? franchiseeId, [FromQuery] DateTimeOffset? since)
    {
        using var db = dbFactory.CreateConnection();
        var sql = @"SELECT TOP 200 * FROM ActivityLogs ";
        var where = new List<string>();
        if (!string.IsNullOrWhiteSpace(franchiseeId)) where.Add("FranchiseeId = @FranchiseeId");
        if (since.HasValue) where.Add("(SyncedAt > @Since OR OccurredAt > @Since)");
        if (where.Count > 0) sql += "WHERE " + string.Join(" AND ", where) + " ";
        sql += "ORDER BY OccurredAt DESC";
        var items = await db.QueryAsync<ActivityLog>(sql, new { FranchiseeId = franchiseeId, Since = since });
        return Ok(items);
    }

    // -----------------------------------------------------------------------
    // POST api/activitylogs  (single, immediate submit when online)
    // -----------------------------------------------------------------------
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] ActivityLogSyncItem dto)
    {
        var (result, isNew) = await UpsertAsync(dto);
        return isNew ? CreatedAtAction(nameof(GetAll), new { id = result.Id }, result)
                     : Ok(result);   // idempotent: return existing record
    }

    // -----------------------------------------------------------------------
    // POST api/activitylogs/sync  (batch – offline flush)
    //
    // Idempotency contract: if a record with dto.RequestId already exists the
    // server does NOT insert a duplicate – it returns the existing record.
    // The client sends a client-generated GUID (RequestId) per entry.
    // -----------------------------------------------------------------------
    [HttpPost("sync")]
    public async Task<IActionResult> SyncBatch([FromBody] SyncBatchRequest request)
    {
        if (request.Items == null || request.Items.Count == 0)
            return BadRequest("No items to sync.");

        var response = new SyncBatchResponse();

        foreach (var item in request.Items)
        {
            var (log, isNew) = await UpsertAsync(item);
            response.Results.Add(new SyncItemResult
            {
                RequestId = item.RequestId,
                ServerId = log.Id,
                WasDuplicate = !isNew
            });

            if (isNew) response.Accepted++;
            else response.Duplicate++;
        }

        logger.LogInformation("Sync batch: {Accepted} accepted, {Duplicate} duplicates.",
            response.Accepted, response.Duplicate);

        return Ok(response);
    }

    // -----------------------------------------------------------------------
    private async Task<(ActivityLog log, bool isNew)> UpsertAsync(ActivityLogSyncItem dto)
    {
        using var db = dbFactory.CreateConnection();

        const string insertSql = """
            INSERT INTO ActivityLogs
                (RequestId, FranchiseeId, ActivityType, Notes, PhReading, TemperatureCelsius, OccurredAt, SyncedAt, SyncStatus)
            OUTPUT INSERTED.*
            VALUES
                (@RequestId, @FranchiseeId, @ActivityType, @Notes, @PhReading, @TemperatureCelsius, @OccurredAt, @SyncedAt, @SyncStatus)
            """;

        try
        {
            var inserted = await db.QuerySingleAsync<ActivityLog>(insertSql, new
            {
                dto.RequestId,
                dto.FranchiseeId,
                dto.ActivityType,
                dto.Notes,
                dto.PhReading,
                dto.TemperatureCelsius,
                dto.OccurredAt,
                SyncedAt = DateTimeOffset.UtcNow,
                SyncStatus = (int)SyncStatus.Synced
            });

            return (inserted, true);
        }
        catch (SqlException ex) when (ex.Number == 2627 || ex.Number == 2601)
        {
            // Unique constraint violation on RequestId – another process already
            // inserted the same RequestId. Return the existing row (idempotent).
            var existing = await db.QuerySingleAsync<ActivityLog>(
                "SELECT * FROM ActivityLogs WHERE RequestId = @RequestId",
                new { dto.RequestId });
            return (existing, false);
        }
    }
}
