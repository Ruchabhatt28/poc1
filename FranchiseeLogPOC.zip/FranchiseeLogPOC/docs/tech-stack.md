# Technology Stack

This document explains every technology used in the Franchisee Log POC, what it does, and why it was chosen.

---

## Backend — ASP.NET Core 9 Web API

| What | Why |
|---|---|
| C# / .NET 9 | Existing team skill set; strong typing; excellent tooling |
| ASP.NET Core 9 | Industry-standard, high-performance, cross-platform API framework |
| Controller-based API (`[ApiController]`) | Familiar pattern; clear separation of endpoints; easy to test |

The API is the single source of truth. It accepts activity logs from franchisees (both online-immediate and offline-batched), stores scheduled events, and manages push notification subscriptions.

---

## Database — SQL Server + Dapper

| What | Why |
|---|---|
| **SQL Server** | Existing corporate database platform; familiar to the team |
| **Dapper** | Lightweight micro-ORM for direct SQL with low overhead; chosen for clarity and minimal dependencies in the POC |
| **Idempotent `RequestId` index** | Prevents duplicate records when the client retries a sync (unique constraint at the DB level) |

The database stores:
- `ActivityLogs` — every franchisee log entry with its sync timestamp
- `ScheduledEvents` — recurring and one-off schedules with notification settings
- `PushSubscriptions` — browser push endpoint + keys per franchisee device

---

## Authentication — Microsoft Entra ID (Azure AD) + MSAL

| What | Why |
|---|---|
| **Microsoft Entra ID (Azure AD)** | The organisation already authenticates via corporate email through Azure — reusing the same identity provider keeps a single sign-on experience |
| **MSAL.js (client side)** | Microsoft's official library for Blazor WASM to perform OAuth 2.0 PKCE login against Entra ID |
| **Microsoft.Identity.Web (server side)** | Validates the JWT bearer token on every API request; extracts user claims |
| **JWT Bearer tokens** | Stateless; API doesn't need session storage; scales horizontally |

The franchisee clicks **Sign in**, is redirected to the organisation's Microsoft login page, authenticates with their corporate email, and is returned to the app with a token. That token is automatically attached to every API call.

---

## Frontend — Blazor WebAssembly PWA

| What | Why chosen over alternatives |
|---|---|
| **Blazor WebAssembly** | Full C# in the browser — no JavaScript framework (React/Angular/Vue) to learn or maintain separately |
| **PWA (Progressive Web App)** | Installable on tablet/phone home screen; service worker caches the app shell for offline use; same codebase serves browser and "app-like" mobile experience |
| **Single Page Application (SPA)** | Fast navigation after initial load; works well offline once cached |

### Why not React / Angular / Vue?
The team works in C#. Blazor WASM means the same language, tooling, debugging experience, and NuGet ecosystem are used end-to-end without a separate JS build pipeline.

### Why not Blazor Server?
Blazor Server requires a constant SignalR connection to the server. It breaks when offline — exactly the scenario franchisees face on tablets in the field.

### Why not a native Android/iOS app?
A PWA installed to the home screen is functionally equivalent for this use case, with a single codebase to maintain. Native app stores and Xamarin/MAUI add deployment and approval overhead not justified at this stage.

---

## UI Framework — MudBlazor 9

| What | Why |
|---|---|
| **MudBlazor** | The leading C#-first Material Design component library for Blazor |
| **Material Design** | Familiar, accessible, well-tested UI patterns; works on all screen sizes |
| **Responsive grid (`MudGrid`)** | Single layout code adapts automatically from phone (360 px) to tablet (768 px) to desktop (1920 px) |
| **MudDrawer / MudAppBar** | Standard mobile navigation pattern (hamburger menu + top bar) |

No custom CSS framework (Bootstrap removed). MudBlazor provides the full component set — forms, tables, chips, dialogs, snackbars — without writing markup from scratch.

---

## Offline Storage — IndexedDB

| What | Why |
|---|---|
| **IndexedDB (via JS interop)** | Asynchronous, browser key/value database for structured objects and larger storage quotas |
| **Used for** | The offline activity log queue — persisting pending entries between page refreshes and app restarts; supports larger queues and atomic writes |

IndexedDB is the storage used in this build (client-side `IndexedDbService` wraps a small JS interop helper). It is preferred over LocalStorage for durability and capacity.

---

## Offline Sync Pattern

| Concept | Implementation |
|---|---|
| **Client `RequestId`** | Every log entry is assigned a `Guid` by the client before it is ever saved or sent |
| **Idempotent API endpoint** | The server checks for an existing record with that `RequestId` before inserting — safe to call multiple times |
| **Batch sync** | `POST /api/activitylogs/sync` accepts an array of entries, processes each idempotently, returns per-item confirmation |
| **Retry / back-off** | `OfflineSyncService` tracks `RetryCount` per entry; gives up after 5 failed attempts |
| **Auto-flush** | When the browser fires the `online` event, `OfflineSyncService` automatically flushes the queue |

---

## Connectivity Detection — Browser Navigator API (JS Interop)

| What | Why |
|---|---|
| `navigator.onLine` | Synchronous read of the browser's current online/offline belief |
| `window.addEventListener('online' / 'offline')` | Browser events fired when connectivity changes |
| **JS Interop** | Blazor WASM cannot directly call browser APIs — a small JS module (`connectivity-interop.js`) bridges the gap using `IJSRuntime` |

This feeds `ConnectivityService` which notifies the rest of the app (layout banner, sync trigger).

---

## Bluetooth Integration — Web Bluetooth API (Phase 2)

| What | Why |
|---|---|
| **Web Bluetooth API** | W3C browser standard for communicating with BLE (Bluetooth Low Energy) devices without any native app or driver |
| **GATT protocol** | Standard profiles for reading sensor data (Environmental Sensing Service, UUID `0x181A`) |
| **JS Interop** | `bluetooth.js` wraps the async browser API; C# `BluetoothService` calls it via `IJSRuntime` |
| **Browser support** | Chrome 56+, Edge 79+, Android Chrome/WebView ✅ · Firefox ❌ · Safari ❌ |

Used to pull pH and temperature readings directly from connected meters into the activity log form — eliminating manual data entry errors.

---

## Push Notifications — Web Push API + Service Worker (Phase 2)

| What | Why |
|---|---|
| **Service Worker** | JavaScript file that the browser runs in the background, independent of the page — receives push payloads even when the app is closed |
| **Web Push Protocol** | IETF standard (RFC 8030) for server-to-browser encrypted push messages |
| **VAPID keys** | The server signs push requests with a private key; the browser verifies with the matching public key — prevents spoofing |
| **Push API** | Browser API for subscribing to a push service; returns an endpoint URL + encryption keys the server uses to deliver messages |
| **Notification API** | Browser API for displaying a native OS notification popup |
| **JS Interop** | `push-notifications.js` handles subscription and local notification display; `PushNotificationService.cs` wraps it |
| **Browser support** | Chrome, Edge, Firefox (desktop + Android) ✅ · iOS requires PWA installed to home screen (iOS 16.4+) |

Enables the server to push reminders for scheduled events (e.g. "Your daily water test is due in 15 minutes") even when the franchisee is not actively looking at the app.

---

## Summary Table

| Layer | Technology | Role |
|---|---|---|
| Backend runtime | .NET 9 / ASP.NET Core | API host |
| Data persistence | SQL Server + EF Core 9 | Permanent data store + schema management |
| Authentication | Entra ID + MSAL + Microsoft.Identity.Web | Corporate SSO, JWT token issuance + validation |
| Frontend runtime | Blazor WebAssembly | C# SPA running in the browser via WebAssembly |
| PWA shell | Service Worker (built-in Blazor PWA) | Offline asset caching + push message receipt |
| UI components | MudBlazor 9 | Responsive Material Design component library |
| Offline queue | Blazored.LocalStorage | Client-side pending entry persistence |
| Connectivity | Web Navigator API (JS interop) | Online/offline detection + sync trigger |
| Bluetooth | Web Bluetooth API (JS interop) | Phase 2: read pH/temperature from BLE sensors |
| Push delivery | Web Push + VAPID (JS interop) | Phase 2: server-initiated browser/Android notifications |
