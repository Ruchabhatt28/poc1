# Architecture, Functionality & Flow

This document describes what the Franchisee Log application does, how the pieces connect, and how data moves through the system.

---

## System Overview

The application gives franchisees a tablet/phone-friendly tool to record operational activities (water tests, cleaning, equipment checks, etc.) whether or not they have internet access. Field and support staff can use the same application on PC. All data is permanently stored in SQL Server and protected by corporate identity (Entra ID).

```
┌─────────────────────────────────────────────────────────────┐
│                    Franchisee Device                         │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │           Blazor WASM PWA (browser / installed)      │   │
│  │                                                      │   │
│  │  UI pages        Services           JS Interop       │   │
│  │  ─────────       ────────           ──────────       │   │
│  │  Dashboard       OfflineSyncSvc     connectivity.js  │   │
│  │  ActivityLog     ConnectivitySvc    bluetooth.js     │   │
│  │  Bluetooth       BluetoothSvc       push-notif.js    │   │
│  │  Notifications   PushNotifSvc                        │   │
│  │                                                      │   │
│  │  LocalStorage (offline queue)                        │   │
│  │  Service Worker  (PWA cache + push receiver)         │   │
│  └──────────────────────────────────────────────────────┘   │
└──────────────────────┬──────────────────────────────────────┘
                       │  HTTPS + JWT Bearer token
                       │  (if network available)
┌──────────────────────▼──────────────────────────────────────┐
│                ASP.NET Core 9 Web API                        │
│                                                              │
│  /api/activitylogs          /api/scheduledevents             │
│  /api/activitylogs/sync     /api/pushsubscriptions           │
│                                                              │
│  Microsoft.Identity.Web  (validates Entra ID JWT)            │
│  Entity Framework Core 9                                     │
└──────────────────────┬──────────────────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────────────────┐
│                    SQL Server                                │
│                                                              │
│  ActivityLogs   ScheduledEvents   PushSubscriptions          │
└─────────────────────────────────────────────────────────────┘
                       ▲
┌──────────────────────┴──────────────────────────────────────┐
│            Microsoft Entra ID (Azure AD)                     │
│     Issues JWT tokens after corporate email login            │
└─────────────────────────────────────────────────────────────┘
```

---

## Core Features

### 1 · Activity Logging

The primary workflow. A franchisee opens the Activity Log page, fills in:
- Activity type (Water Test, Cleaning, Equipment Check, etc.)
- Date and time of occurrence
- Notes
- Optional sensor readings (pH, temperature — entered manually or pulled from Bluetooth device)

On **Submit**, the entry is handled by `OfflineSyncService`:
- If **online** → sent to the API immediately
- If **offline** → saved to LocalStorage and queued for sync

---

### 2 · Offline Mode

This is the critical resilience feature. Franchisees work in locations (pool plant rooms, remote sites) where internet connectivity is unreliable.

**How it works:**

1. Every entry gets a **client-generated `RequestId`** (a GUID) before anything else happens.
2. The entry is written to **LocalStorage** first, always — regardless of connectivity.
3. If online, a sync attempt is made immediately.
4. If offline, the entry sits in the queue with `SyncState = PendingSync`.
5. When the browser's `online` event fires (connectivity restored), `OfflineSyncService` automatically **flushes the queue** via a batch API call.
6. The server processes each item **idempotently** — if an entry with that `RequestId` already exists it returns the existing record rather than inserting a duplicate.
7. After a successful sync, entries are marked `Synced` and pruned from the local queue after 24 hours.

**Retry logic:**
- If a sync attempt fails (API unreachable, network error), the entry stays `PendingSync` and `RetryCount` increments.
- After 5 failed attempts the entry is marked `Failed` and flagged for user review.

**App bar indicator:**
The connectivity state and pending count are always visible in the navigation bar so the franchisee knows at a glance whether they are online and how many entries are waiting.

---

### 3 · Scheduled Events

The API stores recurring and one-off scheduled events per franchisee (e.g. "Daily water test at 09:00", "Weekly equipment inspection on Monday"). These are:
- Displayed on the Dashboard as an upcoming events table
- Used as the source for push notification reminders (Phase 2)

---

### 4 · Bluetooth Sensor Integration (Phase 2)

Removes manual data entry errors for pH and temperature measurements.

**Flow:**
1. Franchisee navigates to the **Bluetooth page**.
2. Browser shows a device picker (OS-level) — franchisee selects their pH meter or thermometer.
3. The app connects to the device over BLE (Bluetooth Low Energy) using the **Environmental Sensing Service** (GATT standard profile, UUID `0x181A`).
4. Tapping **Read Sensors** pulls the current pH and temperature values from the device characteristics.
5. Readings are displayed with acceptable range indicators (pH 7.2–7.6, temp 26–28°C).
6. The franchisee taps **Use in Activity Log** which pre-fills the log form with those readings.

---

### 5 · Push / Browser Notifications (Phase 2)

Provides visible reminders for scheduled events even when the app is not open.

**Setup flow (one-time per device):**
1. Franchisee navigates to the **Notifications page** and grants browser notification permission.
2. The service worker subscribes to the browser's push service using the server's **VAPID public key**.
3. The subscription (endpoint URL + encryption keys) is sent to the API and stored in `PushSubscriptions`.

**Notification delivery flow:**
1. A server-side scheduler (Hangfire / Azure Function in production) checks `ScheduledEvents` for upcoming events.
2. For each event due within `NotifyMinutesBefore` minutes, it sends a **Web Push** message to every stored subscription for that franchisee.
3. The device's push service delivers the encrypted payload to the service worker.
4. The service worker's `push` handler calls `showNotification()` — the OS displays a native notification popup with the event title and body.
5. Tapping the notification opens or focuses the app window.

**Local notifications (no server needed):**
The app can also show instant browser notifications directly from the page for real-time prompts (e.g. confirming a log was saved offline).

---

## Data Flow Diagrams

### A · Online Activity Log Submission

```
Franchisee fills form
        │
        ▼
ActivityLog.razor.SubmitAsync()
        │
        ▼
OfflineSyncService.EnqueueAsync()
   ┌────┴────────────────────────────────────┐
   │  1. Assign RequestId (Guid.NewGuid())   │
   │  2. Save entry to LocalStorage          │
   │     SyncState = PendingSync             │
   │  3. ConnectivityService.IsOnline = true │
   │  4. Call FlushAsync() immediately       │
   └────┬────────────────────────────────────┘
        │
        ▼
POST /api/activitylogs/sync
   { Items: [ { RequestId, ActivityType, ... } ] }
        │
        ▼
ActivityLogsController.SyncBatch()
   ┌────┴────────────────────────────────┐
   │  Check: does RequestId exist in DB? │
   │  No → INSERT new ActivityLog row    │
   │  Yes → return existing row          │
   └────┬────────────────────────────────┘
        │
        ▼
  200 OK { Results: [{ RequestId, ServerId, WasDuplicate }] }
        │
        ▼
OfflineSyncService marks entry Synced
LocalStorage updated, queue banner cleared
```

---

### B · Offline → Reconnect Sync

```
Franchisee fills form (no internet)
        │
        ▼
OfflineSyncService.EnqueueAsync()
   Saves to LocalStorage, SyncState = PendingSync
   FlushAsync() called but API unreachable → RetryCount++

        ... time passes, franchisee submits more entries ...
        ... all queued in LocalStorage ...

Browser fires window 'online' event
        │
        ▼
ConnectivityService.OnConnectivityChanged(true)
        │
        ▼
OfflineSyncService.FlushAsync() (auto-triggered)
   Collects all PendingSync entries
        │
        ▼
POST /api/activitylogs/sync  (single batch for ALL pending entries)
        │
        ▼
API processes idempotently per RequestId
        │
        ▼
Success → each entry marked Synced
          pruned from LocalStorage after 24 h
```

---

### C · Authentication Flow

```
Franchisee opens app (first visit)
        │
        ▼
CascadingAuthenticationState detects unauthenticated
        │
        ▼
RedirectToLogin.razor → NavigateToLogin("authentication/login")
        │
        ▼
MSAL.js redirects browser to:
  https://login.microsoftonline.com/<tenant>/oauth2/v2.0/authorize
        │
        ▼
Franchisee enters corporate email + password (or MFA)
        │
        ▼
Entra ID issues Authorization Code
        │
        ▼
MSAL.js exchanges code for:
  - ID token  (who you are)
  - Access token  (scoped to api://<client-id>/access_as_user)
        │
        ▼
App resumes at /authentication/login-callback
AuthorizeRouteView renders the requested page
        │
        ▼
Every HttpClient call to the API:
  Authorization: Bearer <access-token>
        │
        ▼
API: Microsoft.Identity.Web validates token signature,
     audience, issuer, expiry against Entra ID public keys
        │
        ▼
Request proceeds to controller; [Authorize] is satisfied
```

---

### D · Push Notification Flow (Phase 2)

```
[One-time setup]
Franchisee grants notification permission
        │
        ▼
Service Worker subscribes via PushManager.subscribe(vapidPublicKey)
Returns: { endpoint, p256dhKey, authKey }
        │
        ▼
POST /api/pushsubscriptions  (stores subscription in SQL Server)

─────────────────────────────────────────────────

[When an event is due]
Server scheduler checks ScheduledEvents
Event due in ≤ NotifyMinutesBefore minutes
        │
        ▼
Server calls Web Push protocol:
  POST {subscription.endpoint}
  Headers: Authorization: vapid ...
  Body: encrypted JSON payload
        │
        ▼
Browser push service (Google/Microsoft/Mozilla) delivers to device
        │
        ▼
Service worker 'push' event fires
  self.registration.showNotification(title, options)
        │
        ▼
OS displays native notification popup
        │
        ▼
Franchisee taps notification
  → 'notificationclick' event → app window opens/focuses
```

---

## Project Structure

```
FranchiseeLogPOC/
│
├── docs/
│   ├── tech-stack.md           ← technology choices explained
│   └── architecture.md         ← this document
│
├── src/
│   │
│   ├── FranchiseeLogPOC.Api/
│   │   ├── Controllers/
│   │   │   ├── ActivityLogsController.cs       single + batch sync (idempotent)
│   │   │   ├── ScheduledEventsController.cs    CRUD for schedules
│   │   │   └── PushSubscriptionsController.cs  push subscription storage
│   │   ├── Data/
│   │   │   └── AppDbContext.cs                 EF Core context + seed data
│   │   ├── Models/
│   │   │   ├── ActivityLog.cs                  DB entity
│   │   │   ├── ScheduledEvent.cs               DB entity
│   │   │   ├── PushSubscription.cs             DB entity
│   │   │   └── SyncModels.cs                   request/response DTOs
│   │   ├── Migrations/                         EF Core DB migration scripts
│   │   ├── Program.cs                          DI wiring, auth, CORS, middleware
│   │   └── appsettings.json                    connection string, AzureAd config
│   │
│   └── FranchiseeLogPOC.Client/
│       ├── Layout/
│       │   └── MainLayout.razor                app shell, nav drawer, connectivity badge
│       ├── Models/
│       │   └── ActivityLogEntry.cs             client model + SyncState enum
│       ├── Pages/
│       │   ├── Home.razor                      dashboard: connectivity, queue, schedule
│       │   ├── ActivityLog.razor               main log form + queue table
│       │   ├── BluetoothDemo.razor             Phase 2: BLE sensor page
│       │   ├── NotificationsDemo.razor         Phase 2: push notification page
│       │   └── Authentication.razor            MSAL login/logout callback page
│       ├── Services/
│       │   ├── OfflineSyncService.cs           queue, flush, retry logic
│       │   ├── ConnectivityService.cs          online/offline detection
│       │   ├── BluetoothService.cs             Web Bluetooth JS interop wrapper
│       │   ├── PushNotificationService.cs      Push API JS interop wrapper
│       │   └── ApiClient.cs                    typed HTTP client + DTOs
│       ├── Shared/
│       │   └── RedirectToLogin.razor           unauthenticated redirect component
│       └── wwwroot/
│           ├── index.html                      PWA entry point
│           ├── manifest.webmanifest            PWA install metadata
│           ├── service-worker.published.js     offline cache + push handler
│           ├── appsettings.json                AzureAd, ApiBaseUrl, VapidPublicKey
│           └── js/
│               ├── connectivity-interop.js     online/offline browser events → C#
│               ├── bluetooth.js                Web Bluetooth API wrapper
│               └── push-notifications.js       Push API + Notification API wrapper
│
└── FranchiseeLogPOC.sln
```

---

## Key Design Decisions

### Why a single API for both online and offline sync?

Rather than two separate endpoints, the same `POST /api/activitylogs/sync` is used for both immediate online submissions and offline batch flushes. The client always includes a `RequestId` so the server can detect duplicates. This simplifies the client — it always queues first, syncs second — and the server never needs to know whether data came from an "online" or "offline" path.

### Why LocalStorage and not IndexedDB for the POC?

LocalStorage is simpler to implement, synchronous, and has no browser-specific quirks in Blazor WASM. For a POC with a small queue (dozens, not thousands of entries), it is sufficient. The upgrade path to IndexedDB is well-defined and does not require architectural changes — only swapping the storage backend inside `OfflineSyncService`.

### Why a PWA rather than a native Android app?

| Factor | PWA | Native Android |
|---|---|---|
| Codebase | Single (shared with PC/browser) | Separate |
| Deployment | Web server update | Google Play review |
| Offline | ✅ via service worker | ✅ native |
| Bluetooth | ✅ Web Bluetooth (Chrome) | ✅ native |
| Push notifications | ✅ Web Push | ✅ FCM |
| iOS support | ✅ (installed to home screen) | ❌ (separate app needed) |

For this use case the PWA covers the requirement with one codebase.

### Why is auth not skippable even for offline entries?

The app requires the user to authenticate on first load (when online). The MSAL token is cached and silently refreshed. When offline, previously cached tokens are reused. The `FranchiseeId` is derived from the authenticated user's claim — ensuring every offline entry is attributed to the correct person before it ever reaches the server.
