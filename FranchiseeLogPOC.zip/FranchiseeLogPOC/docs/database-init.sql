-- =============================================================================
-- FranchiseeLogPOC  –  Database initialisation script
-- Run once on a new SQL Server database.
-- The app no longer uses EF Core migrations; this script replaces them.
-- =============================================================================

-- ----------------------------------------------------------------
-- 1. ActivityLogs
-- ----------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'ActivityLogs')
BEGIN
    CREATE TABLE ActivityLogs (
        Id                  INT             IDENTITY(1,1) PRIMARY KEY,
        RequestId           UNIQUEIDENTIFIER NOT NULL,
        FranchiseeId        NVARCHAR(256)   NOT NULL DEFAULT '',
        ActivityType        NVARCHAR(100)   NOT NULL DEFAULT '',
        Notes               NVARCHAR(MAX)   NOT NULL DEFAULT '',
        PhReading           FLOAT           NULL,
        TemperatureCelsius  FLOAT           NULL,
        OccurredAt          DATETIMEOFFSET  NOT NULL,
        SyncedAt            DATETIMEOFFSET  NOT NULL,
        SyncStatus          INT             NOT NULL DEFAULT 0
    );

    -- Unique index on RequestId ensures idempotent offline sync
    CREATE UNIQUE INDEX UX_ActivityLogs_RequestId ON ActivityLogs (RequestId);
END
GO
-- (Scheduled events and push subscription tables removed in simplified build)
