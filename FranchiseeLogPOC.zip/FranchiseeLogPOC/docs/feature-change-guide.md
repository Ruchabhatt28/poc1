**Feature Change Guide — Where to edit code to enable/disable features**

This document maps high-level features to the specific code files to edit and gives minimal, copy-paste friendly instructions for temporarily disabling or changing behavior. You asked to keep the code as-is for now — use these instructions when you want to comment out features or make quick toggles.

- Tip: make small commits so you can revert easily.

| Feature | Client files (Blazor WASM) | API files | Quick change / what to comment or edit |
|---|---|---|---|
| Bluetooth (Web Bluetooth) | *Removed in this simplified build* | The Web Bluetooth integration was removed to focus this POC on robust offline sync. To restore, re-add the Bluetooth service, JS interop and UI pages.

| Push Notifications (Web Push + Service Worker) | *Removed in this simplified build* | Push notification support and service-worker push handling were removed. To reintroduce, add JS interop, service worker, and server subscription endpoints.

| Offline queue / Sync | `src/FranchiseeLogPOC.Client/Services/OfflineSyncService.cs`  
`src/FranchiseeLogPOC.Client/Pages/ActivityLog.razor`  
`src/FranchiseeLogPOC.Client/Services/ConnectivityService.cs` | `src/FranchiseeLogPOC.Api/Controllers/ActivityLogsController.cs` | - To disable offline behavior temporarily: in `Program.cs` comment out `builder.Services.AddScoped<OfflineSyncService>();` and instead directly use the `IApiClient` in the `ActivityLog` page to call the API immediately.  
-- Alternatively, in `OfflineSyncService.EnqueueAsync` early-return after persisting to IndexedDB (so no flush attempts).  
-- To re-enable quickly, undo these changes.  
-- Note: Disabling offline removes the app's ability to queue when offline — useful for debugging but not for PWA use.

| Authentication (Dev bypass vs Entra/MSAL) | `src/FranchiseeLogPOC.Client/Services/DevAuthStateProvider.cs`  
`src/FranchiseeLogPOC.Client/wwwroot/appsettings.json`  
`src/FranchiseeLogPOC.Client/Program.cs` | `src/FranchiseeLogPOC.Api/Auth/DevAuthHandler.cs`  
`src/FranchiseeLogPOC.Api/Program.cs`  
`src/FranchiseeLogPOC.Api/appsettings.json` | - Toggle `UseDevAuth` in `wwwroot/appsettings.Development.json` or `appsettings.json`.  
- When `UseDevAuth=true` the client registers `DevAuthStateProvider` and the API adds `DevAuthHandler`.  
- To disable dev-bypass: set `UseDevAuth:false` and configure real Azure AD Client IDs in both API and Client `appsettings.json` files (and register apps in Entra ID).  

| UI / Navigation | `src/FranchiseeLogPOC.Client/Layout/MainLayout.razor`  
`src/FranchiseeLogPOC.Client/Shared/*` | None | - Remove/hide `MudNavLink` entries to hide pages (Bluetooth, Notifications, Activity Log).  
- Comment out page import lines in `_Imports.razor` if you want to prevent component discovery.

| Service Worker / PWA cache | `src/FranchiseeLogPOC.Client/wwwroot/service-worker.published.js`  
`src/FranchiseeLogPOC.Client/wwwroot/manifest.webmanifest` | None | - To stop PWA behavior during dev, remove the service worker registration from `index.html` (or unregister via browser devtools).  
- Also remove `manifest.webmanifest` link if you want to avoid install prompts.

| Database / ORM (Dapper vs EF) | None (client unchanged) | `src/FranchiseeLogPOC.Api/Data/*`  
`src/FranchiseeLogPOC.Api/Program.cs`  
`src/FranchiseeLogPOC.Api/FranchiseeLogPOC.Api.csproj` | - The API currently uses Dapper + `DbConnectionFactory`. To revert to EF you'd: add EF packages to `csproj`, recreate `AppDbContext.cs`, re-add migrations and `db.Database.Migrate()` call in `Program.cs`.  
- To disable DB calls for testing, stub controllers to return mock data or short-circuit DB calls (e.g. return in-memory lists).

| IndexedDB | `src/FranchiseeLogPOC.Client/Program.cs`  
`src/FranchiseeLogPOC.Client/Services/OfflineSyncService.cs` | None | - `IndexedDbService` is registered in `Program.cs` and used by `OfflineSyncService`. No browser-side installation is required — IndexedDB is a built-in browser API. To temporarily disable persistence, comment out the `OfflineSyncService` registration.

---

Quick examples (copy-paste):

- Comment out Bluetooth service registration in `Program.cs` (Client):

```csharp
// builder.Services.AddScoped<BluetoothService>();
```

- Hide Bluetooth menu item (in `Layout/MainLayout.razor`):

```razor
// <MudNavLink Href="/bluetooth" Icon="@Icons.Material.Filled.Bluetooth">Bluetooth Sensors</MudNavLink>
```

- Disable service worker in `index.html` (remove or comment registration line):

```html
<!-- <script>navigator.serviceWorker.register('service-worker.published.js');</script> -->
```

- Force dev-auth on client (temporary):

```json
// in src/.../wwwroot/appsettings.json
{
  "UseDevAuth": true,
  ...
}
```

Notes and recommendations
- Prefer small, reversible changes: comment out registrations and UI links rather than deleting files. Keep commits focused and revertible.
- For temporary testing, use feature flags (config values) instead of code deletion. Many of these features already read config (e.g. `UseDevAuth`). You can add `EnableBluetooth=false` and gate code with that flag.
- When disabling server-side features (PushSubscriptionsController) consider leaving endpoints but adding a `return BadRequest("Feature disabled in this build");` to make behavior explicit.

If you want, I can:
- Add simple feature flags (JSON keys) and wire checks into the services so you can toggle features without editing code.
- Create a checklist PR that comments out Bluetooth + Push and leaves instructions to revert.

Saved file: `docs/feature-change-guide.md`.

What would you like me to do next? (Add feature flags, make a PR, or comment out specific features now?)