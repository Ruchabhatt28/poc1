<#
Run both API and Blazor client for LAN testing.

Usage: Run this from PowerShell (no admin required unless adding firewall rule).
 - Starts API on http://0.0.0.0:7000
 - Starts Client on http://0.0.0.0:7001
 - Opens the client URL in the default browser

Adjust ports by editing the script if required.
#>

$apiProject = "FranchiseeLogPOC/FranchiseeLogPocApi/FranchiseeLogPOC.Api/FranchiseeLogPOC.Api.csproj"
$clientProject = "FranchiseeLogPOC/FranchiseeLogPocClient/FranchiseeLogPOC.Client/FranchiseeLogPOC.Client.csproj"

Write-Host "Starting API on http://0.0.0.0:7000..."
Start-Process -NoNewWindow powershell -ArgumentList "-NoExit","-Command","dotnet run --project $apiProject --urls 'http://0.0.0.0:7000'"

Start-Sleep -Milliseconds 500

Write-Host "Starting Client on http://0.0.0.0:7001..."
Start-Process -NoNewWindow powershell -ArgumentList "-NoExit","-Command","dotnet run --project $clientProject --urls 'http://0.0.0.0:7001'"

Start-Sleep -Seconds 2

$clientUrl = 'http://192.168.1.29:7001/'
Write-Host "Opening client URL: $clientUrl"
Start-Process $clientUrl

Write-Host "If your tablet cannot reach the app, ensure firewall allows ports 7000 and 7001 (Private network)."
# Optional firewall rule (uncomment to run as admin)
# New-NetFirewallRule -DisplayName "FranchiseeLogPOC HTTP" -Direction Inbound -LocalPort 7000,7001 -Protocol TCP -Action Allow -Profile Private
