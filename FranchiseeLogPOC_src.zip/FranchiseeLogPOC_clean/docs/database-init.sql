-- =============================================================================
-- FranchiseeLogPOC  –  Database initialisation script
-- Run once on a new SQL Server database.
-- The app no longer uses EF Core migrations; this script replaces them.
-- =============================================================================

-- ----------------------------------------------------------------
-- 1. ActivityLogs
-- ----------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'ActivityLogs')
BEGIN
    CREATE TABLE ActivityLogs (
        Id                  INT             IDENTITY(1,1) PRIMARY KEY,
        RequestId           UNIQUEIDENTIFIER NOT NULL,
        FranchiseeId        NVARCHAR(256)   NOT NULL DEFAULT '',
        ActivityType        NVARCHAR(100)   NOT NULL DEFAULT '',
        Notes               NVARCHAR(MAX)   NOT NULL DEFAULT '',
        PhReading           FLOAT           NULL,
        TemperatureCelsius  FLOAT           NULL,
        OccurredAt          DATETIMEOFFSET  NOT NULL,
        SyncedAt            DATETIMEOFFSET  NOT NULL,
        SyncStatus          INT             NOT NULL DEFAULT 0
    );

    -- Unique index on RequestId ensures idempotent offline sync
    CREATE UNIQUE INDEX UX_ActivityLogs_RequestId ON ActivityLogs (RequestId);
END
GO

-- ----------------------------------------------------------------
-- 2. ScheduledEvents
-- ----------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'ScheduledEvents')
BEGIN
    CREATE TABLE ScheduledEvents (
        Id                      INT             IDENTITY(1,1) PRIMARY KEY,
        FranchiseeId            NVARCHAR(256)   NOT NULL DEFAULT '',
        Title                   NVARCHAR(200)   NOT NULL DEFAULT '',
        Description             NVARCHAR(MAX)   NOT NULL DEFAULT '',
        ScheduledAt             DATETIMEOFFSET  NOT NULL,
        IsRecurring             BIT             NOT NULL DEFAULT 0,
        RecurrenceRule          NVARCHAR(500)   NULL,
        NotifyMinutesBefore     INT             NOT NULL DEFAULT 15,
        NotificationSent        BIT             NOT NULL DEFAULT 0,
        CreatedAt               DATETIMEOFFSET  NOT NULL DEFAULT SYSDATETIMEOFFSET()
    );
END
GO

-- Demo seed data
IF NOT EXISTS (SELECT 1 FROM ScheduledEvents WHERE FranchiseeId = 'demo-franchisee')
BEGIN
    INSERT INTO ScheduledEvents (FranchiseeId, Title, Description, ScheduledAt, IsRecurring, RecurrenceRule, NotifyMinutesBefore, NotificationSent)
    VALUES
        ('demo-franchisee', 'Daily Water Quality Check', 'Measure and log pH and temperature readings.',
         DATEADD(hour, 9, CAST(CAST(GETUTCDATE() AS DATE) AS DATETIME2)), 1, 'FREQ=DAILY;INTERVAL=1', 15, 0),
        ('demo-franchisee', 'Weekly Equipment Inspection', 'Inspect all filtration and pumping equipment.',
         DATEADD(hour, 10, DATEADD(day, 1, CAST(CAST(GETUTCDATE() AS DATE) AS DATETIME2))), 1, 'FREQ=WEEKLY;BYDAY=MO', 30, 0);
END
GO

-- ----------------------------------------------------------------
-- 3. PushSubscriptions
-- ----------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'PushSubscriptions')
BEGIN
    CREATE TABLE PushSubscriptions (
        Id              INT             IDENTITY(1,1) PRIMARY KEY,
        FranchiseeId    NVARCHAR(256)   NOT NULL DEFAULT '',
        Endpoint        NVARCHAR(1024)  NOT NULL DEFAULT '',
        P256DhKey       NVARCHAR(512)   NOT NULL DEFAULT '',
        AuthKey         NVARCHAR(256)   NOT NULL DEFAULT '',
        CreatedAt       DATETIMEOFFSET  NOT NULL DEFAULT SYSDATETIMEOFFSET()
    );
END
GO
