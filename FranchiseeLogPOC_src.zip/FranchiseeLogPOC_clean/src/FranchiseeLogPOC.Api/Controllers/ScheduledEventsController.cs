using Dapper;
using FranchiseeLogPOC.Api.Data;
using FranchiseeLogPOC.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FranchiseeLogPOC.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ScheduledEventsController(DbConnectionFactory dbFactory) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] string? franchiseeId)
    {
        using var db = dbFactory.CreateConnection();
        var sql = string.IsNullOrWhiteSpace(franchiseeId)
            ? "SELECT * FROM ScheduledEvents ORDER BY ScheduledAt"
            : "SELECT * FROM ScheduledEvents WHERE FranchiseeId = @FranchiseeId ORDER BY ScheduledAt";
        var items = await db.QueryAsync<ScheduledEvent>(sql, new { FranchiseeId = franchiseeId });
        return Ok(items);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] ScheduledEvent evt)
    {
        evt.CreatedAt = DateTimeOffset.UtcNow;
        using var db = dbFactory.CreateConnection();
        const string sql = """
            INSERT INTO ScheduledEvents
                (FranchiseeId, Title, Description, ScheduledAt, IsRecurring, RecurrenceRule, NotifyMinutesBefore, NotificationSent, CreatedAt)
            OUTPUT INSERTED.*
            VALUES
                (@FranchiseeId, @Title, @Description, @ScheduledAt, @IsRecurring, @RecurrenceRule, @NotifyMinutesBefore, @NotificationSent, @CreatedAt)
            """;
        var inserted = await db.QuerySingleAsync<ScheduledEvent>(sql, evt);
        return CreatedAtAction(nameof(GetAll), new { id = inserted.Id }, inserted);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] ScheduledEvent evt)
    {
        using var db = dbFactory.CreateConnection();
        const string sql = """
            UPDATE ScheduledEvents SET
                Title = @Title, Description = @Description, ScheduledAt = @ScheduledAt,
                IsRecurring = @IsRecurring, RecurrenceRule = @RecurrenceRule,
                NotifyMinutesBefore = @NotifyMinutesBefore
            OUTPUT INSERTED.*
            WHERE Id = @Id
            """;
        var updated = await db.QueryFirstOrDefaultAsync<ScheduledEvent>(sql,
            new { evt.Title, evt.Description, evt.ScheduledAt, evt.IsRecurring, evt.RecurrenceRule, evt.NotifyMinutesBefore, Id = id });
        return updated is null ? NotFound() : Ok(updated);
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        using var db = dbFactory.CreateConnection();
        var affected = await db.ExecuteAsync("DELETE FROM ScheduledEvents WHERE Id = @Id", new { Id = id });
        return affected == 0 ? NotFound() : NoContent();
    }
}
