using Dapper;
using FranchiseeLogPOC.Api.Data;
using FranchiseeLogPOC.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FranchiseeLogPOC.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ActivityLogsController(DbConnectionFactory dbFactory, ILogger<ActivityLogsController> logger)
    : ControllerBase
{
    // -----------------------------------------------------------------------
    // GET api/activitylogs?franchiseeId=xxx
    // -----------------------------------------------------------------------
    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] string? franchiseeId)
    {
        using var db = dbFactory.CreateConnection();
        var sql = string.IsNullOrWhiteSpace(franchiseeId)
            ? "SELECT TOP 200 * FROM ActivityLogs ORDER BY OccurredAt DESC"
            : "SELECT TOP 200 * FROM ActivityLogs WHERE FranchiseeId = @FranchiseeId ORDER BY OccurredAt DESC";
        var items = await db.QueryAsync<ActivityLog>(sql, new { FranchiseeId = franchiseeId });
        return Ok(items);
    }

    // -----------------------------------------------------------------------
    // POST api/activitylogs  (single, immediate submit when online)
    // -----------------------------------------------------------------------
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] ActivityLogSyncItem dto)
    {
        var (result, isNew) = await UpsertAsync(dto);
        return isNew ? CreatedAtAction(nameof(GetAll), new { id = result.Id }, result)
                     : Ok(result);   // idempotent: return existing record
    }

    // -----------------------------------------------------------------------
    // POST api/activitylogs/sync  (batch – offline flush)
    //
    // Idempotency contract: if a record with dto.RequestId already exists the
    // server does NOT insert a duplicate – it returns the existing record.
    // The client sends a client-generated GUID (RequestId) per entry.
    // -----------------------------------------------------------------------
    [HttpPost("sync")]
    public async Task<IActionResult> SyncBatch([FromBody] SyncBatchRequest request)
    {
        if (request.Items == null || request.Items.Count == 0)
            return BadRequest("No items to sync.");

        var response = new SyncBatchResponse();

        foreach (var item in request.Items)
        {
            var (log, isNew) = await UpsertAsync(item);
            response.Results.Add(new SyncItemResult
            {
                RequestId = item.RequestId,
                ServerId = log.Id,
                WasDuplicate = !isNew
            });

            if (isNew) response.Accepted++;
            else response.Duplicate++;
        }

        logger.LogInformation("Sync batch: {Accepted} accepted, {Duplicate} duplicates.",
            response.Accepted, response.Duplicate);

        return Ok(response);
    }

    // -----------------------------------------------------------------------
    private async Task<(ActivityLog log, bool isNew)> UpsertAsync(ActivityLogSyncItem dto)
    {
        using var db = dbFactory.CreateConnection();

        var existing = await db.QueryFirstOrDefaultAsync<ActivityLog>(
            "SELECT * FROM ActivityLogs WHERE RequestId = @RequestId",
            new { dto.RequestId });

        if (existing is not null)
            return (existing, false);

        const string insertSql = """
            INSERT INTO ActivityLogs
                (RequestId, FranchiseeId, ActivityType, Notes, PhReading, TemperatureCelsius, OccurredAt, SyncedAt, SyncStatus)
            OUTPUT INSERTED.*
            VALUES
                (@RequestId, @FranchiseeId, @ActivityType, @Notes, @PhReading, @TemperatureCelsius, @OccurredAt, @SyncedAt, @SyncStatus)
            """;

        var inserted = await db.QuerySingleAsync<ActivityLog>(insertSql, new
        {
            dto.RequestId,
            dto.FranchiseeId,
            dto.ActivityType,
            dto.Notes,
            dto.PhReading,
            dto.TemperatureCelsius,
            dto.OccurredAt,
            SyncedAt = DateTimeOffset.UtcNow,
            SyncStatus = (int)SyncStatus.Synced
        });

        return (inserted, true);
    }
}
