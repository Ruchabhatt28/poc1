using Dapper;
using FranchiseeLogPOC.Api.Data;
using FranchiseeLogPOC.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FranchiseeLogPOC.Api.Controllers;

/// <summary>
/// Manages Web Push subscriptions.
/// In a full implementation the server would use a Web Push library (e.g. WebPush)
/// to send notifications. This POC stores subscriptions and exposes a trigger
/// endpoint so you can fire a test notification from the client.
/// </summary>
[ApiController]
[Route("api/[controller]")]
[Authorize]
public class PushSubscriptionsController(DbConnectionFactory dbFactory, ILogger<PushSubscriptionsController> logger)
    : ControllerBase
{
    // Upsert subscription by endpoint (same device re-subscribing replaces old record)
    [HttpPost]
    public async Task<IActionResult> Subscribe([FromBody] PushSubscriptionDto dto)
    {
        using var db = dbFactory.CreateConnection();
        const string sql = """
            IF EXISTS (SELECT 1 FROM PushSubscriptions WHERE Endpoint = @Endpoint)
                UPDATE PushSubscriptions
                SET FranchiseeId = @FranchiseeId, P256DhKey = @P256DhKey, AuthKey = @AuthKey
                WHERE Endpoint = @Endpoint
            ELSE
                INSERT INTO PushSubscriptions (FranchiseeId, Endpoint, P256DhKey, AuthKey, CreatedAt)
                VALUES (@FranchiseeId, @Endpoint, @P256DhKey, @AuthKey, @CreatedAt)
            """;
        await db.ExecuteAsync(sql, new
        {
            dto.FranchiseeId,
            dto.Endpoint,
            dto.P256DhKey,
            dto.AuthKey,
            CreatedAt = DateTimeOffset.UtcNow
        });
        return Ok(new { message = "Subscribed." });
    }

    [HttpDelete]
    public async Task<IActionResult> Unsubscribe([FromBody] string endpoint)
    {
        using var db = dbFactory.CreateConnection();
        await db.ExecuteAsync("DELETE FROM PushSubscriptions WHERE Endpoint = @Endpoint", new { Endpoint = endpoint });
        return NoContent();
    }

    /// <summary>
    /// POC demo endpoint – triggers a fake push notification payload back to the caller.
    /// In production this calls the Web Push protocol against each stored subscription.
    /// </summary>
    [HttpPost("trigger-demo")]
    public async Task<IActionResult> TriggerDemo([FromBody] TriggerNotificationDto dto)
    {
        using var db = dbFactory.CreateConnection();
        var subs = (await db.QueryAsync<PushSubscription>(
            "SELECT * FROM PushSubscriptions WHERE FranchiseeId = @FranchiseeId",
            new { dto.FranchiseeId })).ToList();

        logger.LogInformation("Triggering demo notification for {FranchiseeId}: {SubCount} subscriptions.",
            dto.FranchiseeId, subs.Count);

        // In production: use WebPush NuGet library here.
        return Ok(new
        {
            message = $"Would push to {subs.Count} subscription(s). Wire in a WebPush library for real delivery.",
            subscriptionCount = subs.Count,
            payload = new { title = dto.Title, body = dto.Body }
        });
    }
}

public record PushSubscriptionDto(
    string FranchiseeId,
    string Endpoint,
    string P256DhKey,
    string AuthKey);

public record TriggerNotificationDto(
    string FranchiseeId,
    string Title,
    string Body);
