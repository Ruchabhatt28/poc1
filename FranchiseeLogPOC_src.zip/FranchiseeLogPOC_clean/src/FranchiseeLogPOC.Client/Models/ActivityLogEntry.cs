namespace FranchiseeLogPOC.Client.Models;

/// <summary>
/// Client-side model for an activity log entry.
/// Also used as the offline queue item stored in LocalStorage.
/// </summary>
public class ActivityLogEntry
{
    /// <summary>Client-generated GUID – used for idempotent server sync.</summary>
    public Guid RequestId { get; set; } = Guid.NewGuid();

    public string FranchiseeId { get; set; } = "demo-franchisee";
    public string ActivityType { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;

    // Sensor readings from Bluetooth devices (Phase 2)
    public double? PhReading { get; set; }
    public double? TemperatureCelsius { get; set; }

    public DateTimeOffset OccurredAt { get; set; } = DateTimeOffset.UtcNow;

    /// <summary>
    /// Sync tracking – updated by OfflineSyncService.
    /// </summary>
    public SyncState SyncState { get; set; } = SyncState.PendingSync;
    public int? ServerId { get; set; }
    public string? SyncError { get; set; }
    public int RetryCount { get; set; }
}

public enum SyncState
{
    PendingSync = 0,
    Syncing = 1,
    Synced = 2,
    Failed = 3
}

public class ScheduledEventDto
{
    public int Id { get; set; }
    public string FranchiseeId { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public DateTimeOffset ScheduledAt { get; set; }
    public bool IsRecurring { get; set; }
    public string? RecurrenceRule { get; set; }
    public int NotifyMinutesBefore { get; set; } = 15;
}
