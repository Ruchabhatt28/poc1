// ============================================================================
// bluetooth.js  –  Phase 2 Bluetooth sensor integration
// Uses the Web Bluetooth API (Chrome / Edge / Android Chrome).
//
// Standard UUIDs used here (replace with device-specific UUIDs for production):
//   Service:            Environmental Sensing (0x181A)
//   pH Characteristic:  0x2BE6  (Custom – many pH meters use proprietary UUIDs)
//   Temp Characteristic:0x2A6E  (Temperature – ESS standard)
// ============================================================================

window.bluetoothInterop = (() => {
    let device = null;
    let server = null;

    // Service / characteristic UUIDs
    const ESS_SERVICE_UUID = 0x181A;
    const TEMP_CHAR_UUID   = 0x2A6E;
    // NOTE: pH has no standard GATT UUID – 0x2BE6 is a placeholder.
    // Replace with your sensor's custom UUID (check manufacturer docs).
    const PH_CHAR_UUID     = '00002be6-0000-1000-8000-00805f9b34fb';

    return {
        /** True if the browser implements navigator.bluetooth */
        isSupported() {
            return typeof navigator.bluetooth !== 'undefined';
        },

        /**
         * Shows browser device picker filtered to ESS sensors.
         * Returns the device name once connected, or null.
         */
        async requestDevice() {
            if (!this.isSupported()) return null;
            try {
                device = await navigator.bluetooth.requestDevice({
                    filters: [{ services: [ESS_SERVICE_UUID] }],
                    // For demo/testing: accept any device
                    // acceptAllDevices: true,
                    // optionalServices: [ESS_SERVICE_UUID]
                });
                server = await device.gatt.connect();
                console.log('[Bluetooth] Connected to:', device.name);
                return device.name;
            } catch (err) {
                console.warn('[Bluetooth] requestDevice error:', err.message);
                return null;
            }
        },

        /**
         * Reads pH value from the connected device.
         * Returns a float or null on error.
         */
        async readPh() {
            if (!server?.connected) return null;
            try {
                const svc  = await server.getPrimaryService(ESS_SERVICE_UUID);
                const char = await svc.getCharacteristic(PH_CHAR_UUID);
                const val  = await char.readValue();
                // ESS pH is stored as uint16 with a resolution of 0.01
                // (i.e. raw value 714 = pH 7.14).  Adjust for your device.
                const raw = val.getUint16(0, /*littleEndian=*/ true);
                return raw / 100;
            } catch (err) {
                console.warn('[Bluetooth] readPh error:', err.message);
                return null;
            }
        },

        /**
         * Reads temperature from the connected device.
         * ESS Temperature (0x2A6E) is sint16, units 0.01 °C.
         */
        async readTemperature() {
            if (!server?.connected) return null;
            try {
                const svc  = await server.getPrimaryService(ESS_SERVICE_UUID);
                const char = await svc.getCharacteristic(TEMP_CHAR_UUID);
                const val  = await char.readValue();
                const raw  = val.getInt16(0, true);   // signed, little-endian
                return raw / 100;
            } catch (err) {
                console.warn('[Bluetooth] readTemperature error:', err.message);
                return null;
            }
        },

        /** Disconnects the GATT server. */
        async disconnect() {
            if (server?.connected) {
                server.disconnect();
                console.log('[Bluetooth] Disconnected.');
            }
            device = null;
            server = null;
        }
    };
})();
