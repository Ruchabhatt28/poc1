// ============================================================================
// push-notifications.js  –  Web Push + Notification API interop
//
// Supports:
//   - Browser/desktop notifications (chrome, edge, firefox)
//   - Android PWA push notifications
//   - iOS PWA push (16.4+ when installed to home screen)
// ============================================================================

window.pushInterop = (() => {

    return {
        /** True if this browser supports Push + Notifications */
        isSupported() {
            return ('Notification' in window) &&
                   ('serviceWorker' in navigator) &&
                   ('PushManager' in window);
        },

        /** Current permission state: 'default' | 'granted' | 'denied' */
        getPermission() {
            return Notification.permission;
        },

        /** Requests notification permission and returns the result. */
        async requestPermission() {
            if (!('Notification' in window)) return 'denied';
            const result = await Notification.requestPermission();
            return result;
        },

        /**
         * Subscribes to Web Push using a VAPID public key.
         * Requires the service worker to be registered.
         * Returns { endpoint, p256DhKey, authKey } or null.
         */
        async subscribe(vapidPublicKey) {
            try {
                const reg = await navigator.serviceWorker.ready;
                const sub = await reg.pushManager.subscribe({
                    userVisibleOnly: true,
                    applicationServerKey: urlBase64ToUint8Array(vapidPublicKey)
                });

                const keys = sub.getKey ? {
                    p256DhKey: btoa(String.fromCharCode(...new Uint8Array(sub.getKey('p256dh')))),
                    authKey:   btoa(String.fromCharCode(...new Uint8Array(sub.getKey('auth'))))
                } : { p256DhKey: '', authKey: '' };

                return {
                    endpoint:  sub.endpoint,
                    p256DhKey: keys.p256DhKey,
                    authKey:   keys.authKey
                };
            } catch (err) {
                console.warn('[Push] subscribe error:', err.message);
                return null;
            }
        },

        /** Shows a local browser notification immediately (no server required). */
        showLocal(title, body) {
            if (Notification.permission !== 'granted') return;
            new Notification(title, {
                body,
                icon: '/icon-192.png',
                badge: '/icon-192.png'
            });
        },

        /** Shows a schedule reminder local notification. */
        showScheduleReminder(eventTitle, scheduledTimeString) {
            this.showLocal(
                `⏰ Reminder: ${eventTitle}`,
                `Scheduled at ${scheduledTimeString}`
            );
        }
    };

    // ---- helper: convert VAPID public key from base64url to Uint8Array ----
    function urlBase64ToUint8Array(base64String) {
        const padding = '='.repeat((4 - base64String.length % 4) % 4);
        const base64  = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
        const raw     = window.atob(base64);
        return Uint8Array.from([...raw].map(c => c.charCodeAt(0)));
    }
})();
