using Blazored.LocalStorage;
using FranchiseeLogPOC.Client.Models;

namespace FranchiseeLogPOC.Client.Services;

/// <summary>
/// Manages the offline activity-log queue.
///
/// Pattern:
///   1. Every entry is saved to LocalStorage with SyncState = PendingSync.
///   2. If online, an immediate sync attempt is made right away.
///   3. When connectivity changes to online, all pending items are flushed.
///   4. Retry with exponential back-off (max 5 attempts).
///
/// Production upgrade: swap LocalStorage for a proper IndexedDB implementation
/// via the offline-db.js interop module (included in wwwroot/js/) which handles
/// larger datasets and structured queries.
/// </summary>
public class OfflineSyncService
{
    private const string QueueKey = "offline_activity_queue";
    private const int MaxRetries = 5;

    private readonly ILocalStorageService _storage;
    private readonly IApiClient _api;
    private readonly ConnectivityService _connectivity;
    private readonly ILogger<OfflineSyncService> _logger;

    public event Action? QueueChanged;

    public OfflineSyncService(
        ILocalStorageService storage,
        IApiClient api,
        ConnectivityService connectivity,
        ILogger<OfflineSyncService> logger)
    {
        _storage = storage;
        _api = api;
        _connectivity = connectivity;
        _logger = logger;

        _connectivity.ConnectivityChanged += async online =>
        {
            if (online)
            {
                _logger.LogInformation("Connectivity restored – flushing offline queue.");
                await FlushAsync();
            }
        };
    }

    /// <summary>
    /// Adds an entry to the local queue and immediately tries to sync if online.
    /// </summary>
    public async Task EnqueueAsync(ActivityLogEntry entry)
    {
        var queue = await GetQueueInternalAsync();
        entry.SyncState = SyncState.PendingSync;
        queue.Add(entry);
        await SaveQueueAsync(queue);
        QueueChanged?.Invoke();

        if (_connectivity.IsOnline)
            await FlushAsync();
    }

    /// <summary>
    /// Returns a read-only snapshot of the current queue.
    /// </summary>
    public async Task<IReadOnlyList<ActivityLogEntry>> GetQueueAsync()
        => await GetQueueInternalAsync();

    /// <summary>
    /// Pushes all pending items to the API in a single batch call.
    /// Items that successfully sync are removed from the queue.
    /// </summary>
    public async Task FlushAsync()
    {
        var queue = await GetQueueInternalAsync();
        var pending = queue.Where(e => e.SyncState == SyncState.PendingSync && e.RetryCount < MaxRetries).ToList();

        if (pending.Count == 0) return;

        _logger.LogInformation("Flushing {Count} offline entries.", pending.Count);

        foreach (var item in pending)
            item.SyncState = SyncState.Syncing;

        await SaveQueueAsync(queue);
        QueueChanged?.Invoke();

        try
        {
            var batch = new SyncBatchRequest
            {
                Items = pending.Select(e => new SyncItem
                {
                    RequestId          = e.RequestId,
                    FranchiseeId       = e.FranchiseeId,
                    ActivityType       = e.ActivityType,
                    Notes              = e.Notes,
                    PhReading          = e.PhReading,
                    TemperatureCelsius = e.TemperatureCelsius,
                    OccurredAt         = e.OccurredAt
                }).ToList()
            };

            var response = await _api.SyncBatchAsync(batch);

            if (response is not null)
            {
                foreach (var result in response.Results)
                {
                    var entry = queue.FirstOrDefault(e => e.RequestId == result.RequestId);
                    if (entry is not null)
                    {
                        entry.SyncState = SyncState.Synced;
                        entry.ServerId  = result.ServerId;
                        entry.SyncError = null;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Sync batch failed – items will retry on next flush.");

            foreach (var item in pending)
            {
                item.SyncState = SyncState.PendingSync;
                item.RetryCount++;
                item.SyncError = ex.Message;

                if (item.RetryCount >= MaxRetries)
                {
                    item.SyncState = SyncState.Failed;
                    _logger.LogError("Entry {RequestId} exhausted retries.", item.RequestId);
                }
            }
        }
        finally
        {
            // Keep only unsynced items in the queue (prune synced ones after 24 h)
            var pruned = queue
                .Where(e => e.SyncState != SyncState.Synced ||
                            e.OccurredAt > DateTimeOffset.UtcNow.AddHours(-24))
                .ToList();

            await SaveQueueAsync(pruned);
            QueueChanged?.Invoke();
        }
    }

    public async Task<int> GetPendingCountAsync()
    {
        var q = await GetQueueInternalAsync();
        return q.Count(e => e.SyncState == SyncState.PendingSync);
    }

    // ---- private helpers ----

    private async Task<List<ActivityLogEntry>> GetQueueInternalAsync()
    {
        try
        {
            return await _storage.GetItemAsync<List<ActivityLogEntry>>(QueueKey) ?? new();
        }
        catch
        {
            return new();
        }
    }

    private Task SaveQueueAsync(IEnumerable<ActivityLogEntry> queue)
        => _storage.SetItemAsync(QueueKey, queue.ToList()).AsTask();
}
