using Microsoft.JSInterop;

namespace FranchiseeLogPOC.Client.Services;

/// <summary>
/// Wraps the browser's Push API and Notification API.
///
/// Flow:
///   1. User grants notification permission.
///   2. Service worker subscribes to push using the VAPID public key.
///   3. Subscription endpoint + keys are sent to the API for storage.
///   4. Server sends Web Push payloads; service worker shows the notification.
///
/// Browser support: Chrome, Edge, Firefox (desktop/Android).
///                  iOS PWA (16.4+) supports notifications when installed.
/// </summary>
public class PushNotificationService
{
    private readonly IJSRuntime _js;
    private readonly IApiClient _api;

    public PushNotificationService(IJSRuntime js, IApiClient api)
    {
        _js = js;
        _api = api;
    }

    /// <summary>Checks if Push is supported in this browser.</summary>
    public ValueTask<bool> IsSupportedAsync()
        => _js.InvokeAsync<bool>("pushInterop.isSupported");

    /// <summary>Returns current notification permission state: "default", "granted", "denied".</summary>
    public ValueTask<string> GetPermissionAsync()
        => _js.InvokeAsync<string>("pushInterop.getPermission");

    /// <summary>Requests notification permission from the user.</summary>
    public ValueTask<string> RequestPermissionAsync()
        => _js.InvokeAsync<string>("pushInterop.requestPermission");

    /// <summary>
    /// Subscribes to push notifications using the provided VAPID public key,
    /// then registers the subscription with the backend API.
    /// </summary>
    public async Task<bool> SubscribeAsync(string franchiseeId, string vapidPublicKey)
    {
        var sub = await _js.InvokeAsync<PushSubscriptionJs?>("pushInterop.subscribe", vapidPublicKey);
        if (sub is null) return false;

        await _api.SubscribePushAsync(new PushSubscriptionPayload
        {
            FranchiseeId = franchiseeId,
            Endpoint     = sub.Endpoint,
            P256DhKey    = sub.P256DhKey,
            AuthKey      = sub.AuthKey
        });

        return true;
    }

    /// <summary>Fires a local (browser-native) notification – no server required.</summary>
    public ValueTask ShowLocalNotificationAsync(string title, string body)
        => _js.InvokeVoidAsync("pushInterop.showLocal", title, body);

    /// <summary>Simulates a scheduled-event reminder notification locally.</summary>
    public ValueTask ShowScheduleReminderAsync(string eventTitle, DateTimeOffset scheduledAt)
        => _js.InvokeVoidAsync("pushInterop.showScheduleReminder", eventTitle,
            scheduledAt.ToLocalTime().ToString("g"));
}

/// <summary>Mirrors the JS PushSubscription object keys sent back via interop.</summary>
internal record PushSubscriptionJs(string Endpoint, string P256DhKey, string AuthKey);
