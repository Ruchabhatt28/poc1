using Microsoft.JSInterop;

namespace FranchiseeLogPOC.Client.Services;

/// <summary>
/// Provides Phase 2 Bluetooth device connectivity via the Web Bluetooth API.
///
/// Browser support: Chrome 56+, Edge 79+, Android Chrome/WebView.
/// NOT supported in Firefox or Safari (as of 2026).
///
/// The JS interop module (wwwroot/js/bluetooth.js) wraps the Web Bluetooth API
/// so this C# service stays clean.
/// </summary>
public class BluetoothService
{
    private readonly IJSRuntime _js;

    public BluetoothService(IJSRuntime js) => _js = js;

    /// <summary>
    /// Checks if the current browser supports the Web Bluetooth API.
    /// </summary>
    public ValueTask<bool> IsSupportedAsync()
        => _js.InvokeAsync<bool>("bluetoothInterop.isSupported");

    /// <summary>
    /// Prompts the user with a browser picker to select a Bluetooth device.
    /// Returns the device name or null if cancelled / unsupported.
    /// </summary>
    public ValueTask<string?> RequestDeviceAsync()
        => _js.InvokeAsync<string?>("bluetoothInterop.requestDevice");

    /// <summary>
    /// Reads the pH value from a connected device.
    /// Uses standard Environmental Sensing Service (ESS) UUID 0x181A,
    /// characteristic 0x2BE6 (True Wind Direction is a placeholder –
    /// replace with your device's custom UUID in production).
    /// </summary>
    public ValueTask<double?> ReadPhAsync()
        => _js.InvokeAsync<double?>("bluetoothInterop.readPh");

    /// <summary>
    /// Reads the temperature from the connected device.
    /// Uses ESS Temperature characteristic UUID 0x2A6E.
    /// </summary>
    public ValueTask<double?> ReadTemperatureAsync()
        => _js.InvokeAsync<double?>("bluetoothInterop.readTemperature");

    /// <summary>
    /// Disconnects the currently connected device.
    /// </summary>
    public ValueTask DisconnectAsync()
        => _js.InvokeVoidAsync("bluetoothInterop.disconnect");
}
