using Microsoft.AspNetCore.Components.Authorization;
using System.Security.Claims;

namespace FranchiseeLogPOC.Client.Services;

/// <summary>
/// Development-only authentication state provider.
/// Returns a pre-authenticated fake user so the whole UI renders
/// without needing an Entra ID app registration.
///
/// Activated when UseDevAuth=true in wwwroot/appsettings.Development.json.
/// Set UseDevAuth=false once Entra is configured – MSAL takes over automatically.
/// </summary>
public class DevAuthStateProvider : AuthenticationStateProvider
{
    private static readonly AuthenticationState _state = BuildState();

    public override Task<AuthenticationState> GetAuthenticationStateAsync()
        => Task.FromResult(_state);

    private static AuthenticationState BuildState()
    {
        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, "dev-user-id"),
            new Claim(ClaimTypes.Name,           "Dev User"),
            new Claim(ClaimTypes.Email,          "devuser@qualified.domain.name"),
            new Claim("preferred_username",      "devuser@qualified.domain.name"),
        };

        var identity = new ClaimsIdentity(claims, authenticationType: "DevAuth");
        return new AuthenticationState(new ClaimsPrincipal(identity));
    }
}
