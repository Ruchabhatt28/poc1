using Microsoft.JSInterop;

namespace FranchiseeLogPOC.Client.Services;

/// <summary>
/// Tracks browser online/offline state and fires events when connectivity changes.
/// Uses JS interop to tap into the browser Navigator API.
/// </summary>
public class ConnectivityService : IAsyncDisposable
{
    private readonly IJSRuntime _js;
    private DotNetObjectReference<ConnectivityService>? _dotNetRef;
    private bool _isOnline = true;

    public bool IsOnline => _isOnline;

    public event Action<bool>? ConnectivityChanged;

    public ConnectivityService(IJSRuntime js)
    {
        _js = js;
    }

    public async Task InitialiseAsync()
    {
        _dotNetRef = DotNetObjectReference.Create(this);
        _isOnline = await _js.InvokeAsync<bool>("connectivityInterop.init", _dotNetRef);
    }

    [JSInvokable]
    public void OnConnectivityChanged(bool isOnline)
    {
        _isOnline = isOnline;
        ConnectivityChanged?.Invoke(isOnline);
    }

    public async ValueTask DisposeAsync()
    {
        await _js.InvokeVoidAsync("connectivityInterop.dispose");
        _dotNetRef?.Dispose();
    }
}
