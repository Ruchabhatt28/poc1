using Microsoft.JSInterop;

namespace FranchiseeLogPOC.Client.Services;

public class IndexedDbService : IIndexedDbService
{
    private readonly IJSRuntime _js;

    public IndexedDbService(IJSRuntime js) => _js = js;

    public async Task<T?> GetItemAsync<T>(string key)
    {
        var result = await _js.InvokeAsync<object?>("indexedDbInterop.getItem", key);
        if (result is null) return default;
        // Marshal via JSON to target type
        var json = System.Text.Json.JsonSerializer.Serialize(result);
        return System.Text.Json.JsonSerializer.Deserialize<T>(json);
    }

    public async Task SetItemAsync<T>(string key, T item)
    {
        await _js.InvokeVoidAsync("indexedDbInterop.setItem", key, item);
    }
}
