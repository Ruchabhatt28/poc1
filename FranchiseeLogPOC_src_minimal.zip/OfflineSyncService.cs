using Blazored.LocalStorage;
using FranchiseeLogPOC.Client.Models;

namespace FranchiseeLogPOC.Client.Services;

/// <summary>
/// Manages the offline activity-log queue.
///
/// Pattern:
///   1. Every entry is saved to LocalStorage with SyncState = PendingSync.
///   2. If online, an immediate sync attempt is made right away.
///   3. When connectivity changes to online, all pending items are flushed.
///   4. A 30-second polling timer retries pending items regardless of browser
///      online/offline events (navigator.onLine is unreliable on Windows when
///      WiFi drops but other network adapters remain present).
///   5. Retry with exponential back-off (max 5 attempts).
/// </summary>
public class OfflineSyncService : IDisposable
{
    // Queue key is namespaced per user so two users on the same device
    // never share or overwrite each other's offline queue.
    private string QueueKey => $"offline_activity_queue_{_userId}";
    private string LastSyncedKey => $"offline_last_synced_{_userId}";
    private const int MaxRetries = 5;
    private static readonly TimeSpan RetryInterval = TimeSpan.FromSeconds(30);

    private readonly IIndexedDbService _storage;
    private readonly IApiClient _api;
    private readonly ConnectivityService _connectivity;
    private readonly ILogger<OfflineSyncService> _logger;
    private readonly Timer _retryTimer;
    private readonly SemaphoreSlim _queueLock = new(1,1);
    private string _userId = "anonymous";  // set via SetUser() before first use

    public event Action? QueueChanged;

    /// <summary>
    /// Call this once after authentication resolves so the queue is namespaced
    /// to the logged-in user. Prevents queue bleed between users on shared devices.
    /// </summary>
    public void SetUser(string userId)
    {
        _userId = string.IsNullOrWhiteSpace(userId) ? "anonymous" : userId;
    }

    public OfflineSyncService(
        IIndexedDbService storage,
        IApiClient api,
        ConnectivityService connectivity,
        ILogger<OfflineSyncService> logger)
    {
        _storage = storage;
        _api = api;
        _connectivity = connectivity;
        _logger = logger;

        // Subscribe to browser online/offline events (best-effort – unreliable on Windows)
        _connectivity.ConnectivityChanged += async online =>
        {
            if (online)
            {
                _logger.LogInformation("Connectivity restored – flushing offline queue and pulling server changes.");
                try
                {
                    await FlushAsync();
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Flush on connectivity restore failed: {Message}", ex.Message);
                }

                try
                {
                    await PullServerEntriesAsync();
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Pulling server entries failed: {Message}", ex.Message);
                }
            }
        };

        // Polling fallback: retry every 30 s regardless of browser events.
        // Initial delay is 5 s so items queued while online get a quick first attempt.
        _retryTimer = new Timer(async _ =>
        {
            var pending = await GetPendingCountAsync();
            if (pending > 0)
            {
                _logger.LogInformation("Retry timer: {Count} pending items – attempting sync.", pending);
                await FlushAsync();
            }
        }, null, TimeSpan.FromSeconds(5), RetryInterval);
    }

    /// <summary>
    /// Adds an entry to the local queue and immediately tries to sync if online.
    /// </summary>
    public async Task EnqueueAsync(ActivityLogEntry entry)
    {
        await _queueLock.WaitAsync();
        try
        {
            var queue = await GetQueueInternalAsync();
            entry.SyncState = SyncState.PendingSync;
            queue.Add(entry);
            await SaveQueueAsync(queue);
        }
        finally
        {
            _queueLock.Release();
            QueueChanged?.Invoke();
        }
        // Do NOT attempt an immediate flush here – the 5-second timer handles
        // the first attempt. This avoids the visible Syncing→Pending flash when
        // the device thinks it's online but the API is unreachable.
    }

    /// <summary>
    /// Try to save the provided entry immediately to the API while
    /// still keeping a local copy so it can be retried if connectivity
    /// drops mid-flight.
    /// Returns true if the server accepted the entry; otherwise false
    /// and the entry is left in the local queue for retry.
    /// </summary>
    public async Task<bool> TrySaveNowAsync(ActivityLogEntry entry)
    {
        // Serialize access to the queue to avoid lost updates from concurrent
        // operations (timer flush, online event, user actions).
        await _queueLock.WaitAsync();
        try
        {
            var queue = await GetQueueInternalAsync();
            entry.SyncState = SyncState.Syncing;
            entry.RetryCount = 0;
            queue.Add(entry);
            await SaveQueueAsync(queue);
        }
        finally
        {
            _queueLock.Release();
            QueueChanged?.Invoke();
        }

        if (!_connectivity.IsOnline)
        {
            // Not online — ensure Pending and return false so caller knows it wasn't shipped.
            entry.SyncState = SyncState.PendingSync;
            entry.SyncError = "Offline – will retry";
            await _queueLock.WaitAsync();
            try
            {
                var q2 = await GetQueueInternalAsync();
                var saved2 = q2.FirstOrDefault(e => e.RequestId == entry.RequestId);
                if (saved2 is not null)
                {
                    saved2.SyncState = entry.SyncState;
                    saved2.SyncError = entry.SyncError;
                    saved2.RetryCount = entry.RetryCount;
                }
                else
                {
                    q2.Add(entry);
                }
                await SaveQueueAsync(q2);
            }
            finally
            {
                _queueLock.Release();
                QueueChanged?.Invoke();
            }
            return false;
        }

        try
        {
            var batch = new SyncBatchRequest
            {
                Items = new List<SyncItem>
                {
                    new SyncItem
                    {
                        RequestId = entry.RequestId,
                        FranchiseeId = entry.FranchiseeId,
                        ActivityType = entry.ActivityType,
                        Notes = entry.Notes,
                        PhReading = entry.PhReading,
                        TemperatureCelsius = entry.TemperatureCelsius,
                        OccurredAt = entry.OccurredAt
                    }
                }
            };

            var response = await _api.SyncBatchAsync(batch);
            if (response is not null && response.Results.Any())
            {
                var result = response.Results.First();
                // Merge results into the latest queue state (don't overwrite
                // concurrent additions). Acquire lock while updating storage.
                await _queueLock.WaitAsync();
                try
                {
                    var q = await GetQueueInternalAsync();
                    var saved = q.FirstOrDefault(e => e.RequestId == result.RequestId);
                    if (saved is not null)
                    {
                        saved.SyncState = SyncState.Synced;
                        saved.ServerId = result.ServerId;
                        saved.SyncError = null;
                    }
                    else
                    {
                        // If the item is unexpectedly missing (edge case), add the synced
                        // record so serverId is preserved for the UI.
                        q.Add(new ActivityLogEntry
                        {
                            RequestId = result.RequestId,
                            FranchiseeId = entry.FranchiseeId,
                            ActivityType = entry.ActivityType,
                            Notes = entry.Notes,
                            PhReading = entry.PhReading,
                            TemperatureCelsius = entry.TemperatureCelsius,
                            OccurredAt = entry.OccurredAt,
                            SyncState = SyncState.Synced,
                            ServerId = result.ServerId
                        });
                    }

                    await SaveQueueAsync(q);
                }
                finally
                {
                    _queueLock.Release();
                    QueueChanged?.Invoke();
                }

                return true;
            }

            // Server didn't return a result – keep for retry.
            entry.SyncState = SyncState.PendingSync;
            entry.SyncError = "Server did not accept entry";
            await _queueLock.WaitAsync();
            try
            {
                var q3 = await GetQueueInternalAsync();
                var saved3 = q3.FirstOrDefault(e => e.RequestId == entry.RequestId);
                if (saved3 is not null)
                {
                    saved3.SyncState = entry.SyncState;
                    saved3.SyncError = entry.SyncError;
                }
                else
                {
                    q3.Add(entry);
                }
                await SaveQueueAsync(q3);
            }
            finally
            {
                _queueLock.Release();
                QueueChanged?.Invoke();
            }
            return false;
        }
        catch (HttpRequestException ex)
        {
            // Network dropped mid-flight – keep for retry.
            _logger.LogWarning("TrySaveNow failed (network): {Message}", ex.Message);
            entry.SyncState = SyncState.PendingSync;
            entry.RetryCount = 0;
            entry.SyncError = "Offline – will retry";
            await _queueLock.WaitAsync();
            try
            {
                var q4 = await GetQueueInternalAsync();
                var saved4 = q4.FirstOrDefault(e => e.RequestId == entry.RequestId);
                if (saved4 is not null)
                {
                    saved4.SyncState = entry.SyncState;
                    saved4.SyncError = entry.SyncError;
                    saved4.RetryCount = entry.RetryCount;
                }
                else
                {
                    q4.Add(entry);
                }
                await SaveQueueAsync(q4);
            }
            finally
            {
                _queueLock.Release();
                QueueChanged?.Invoke();
            }
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "TrySaveNow failed (server error): {Message}", ex.Message);
            entry.SyncState = SyncState.PendingSync;
            entry.RetryCount++;
            entry.SyncError = ex.Message;
            await _queueLock.WaitAsync();
            try
            {
                var q5 = await GetQueueInternalAsync();
                var saved5 = q5.FirstOrDefault(e => e.RequestId == entry.RequestId);
                if (saved5 is not null)
                {
                    saved5.SyncState = entry.SyncState;
                    saved5.RetryCount = entry.RetryCount;
                    saved5.SyncError = entry.SyncError;
                }
                else
                {
                    q5.Add(entry);
                }
                await SaveQueueAsync(q5);
            }
            finally
            {
                _queueLock.Release();
                QueueChanged?.Invoke();
            }
            return false;
        }
    }

    /// <summary>
    /// Returns a read-only snapshot of the current queue.
    /// </summary>
    public async Task<IReadOnlyList<ActivityLogEntry>> GetQueueAsync()
        => await GetQueueInternalAsync();

    /// <summary>
    /// Pushes all pending items to the API in a single batch call.
    /// Items that successfully sync are removed from the queue.
    /// </summary>
    public async Task FlushAsync()
    {
        await _queueLock.WaitAsync();
        try
        {
            var queue = await GetQueueInternalAsync();

            // Reset any orphaned "Syncing" items – these occur when the app refreshed
            // or WiFi dropped mid-flight before the catch block could run.
            foreach (var stuck in queue.Where(e => e.SyncState == SyncState.Syncing))
                stuck.SyncState = SyncState.PendingSync;

            var pending = queue.Where(e => e.SyncState == SyncState.PendingSync && e.RetryCount < MaxRetries).ToList();

            if (pending.Count == 0) return;

            _logger.LogInformation("Flushing {Count} offline entries.", pending.Count);

            foreach (var item in pending)
                item.SyncState = SyncState.Syncing;

            await SaveQueueAsync(queue);
            QueueChanged?.Invoke();

            try
            {
                var batch = new SyncBatchRequest
                {
                    Items = pending.Select(e => new SyncItem
                    {
                        RequestId          = e.RequestId,
                        FranchiseeId       = e.FranchiseeId,
                        ActivityType       = e.ActivityType,
                        Notes              = e.Notes,
                        PhReading          = e.PhReading,
                        TemperatureCelsius = e.TemperatureCelsius,
                        OccurredAt         = e.OccurredAt
                    }).ToList()
                };

                var response = await _api.SyncBatchAsync(batch);

                if (response is not null)
                {
                    // Merge results into the current persisted queue to avoid
                    // overwriting concurrent additions that happened while the
                    // batch was in-flight.
                    var current = await GetQueueInternalAsync();
                    foreach (var result in response.Results)
                    {
                        var entry = current.FirstOrDefault(e => e.RequestId == result.RequestId);
                        if (entry is not null)
                        {
                            entry.SyncState = SyncState.Synced;
                            entry.ServerId  = result.ServerId;
                            entry.SyncError = null;
                        }
                        else
                        {
                            // If missing, add it as a synced entry so UI reflects server id.
                            var matched = pending.FirstOrDefault(p => p.RequestId == result.RequestId);
                            if (matched is not null)
                            {
                                current.Add(new ActivityLogEntry
                                {
                                    RequestId = matched.RequestId,
                                    FranchiseeId = matched.FranchiseeId,
                                    ActivityType = matched.ActivityType,
                                    Notes = matched.Notes,
                                    PhReading = matched.PhReading,
                                    TemperatureCelsius = matched.TemperatureCelsius,
                                    OccurredAt = matched.OccurredAt,
                                    SyncState = SyncState.Synced,
                                    ServerId = result.ServerId
                                });
                            }
                        }
                    }

                    queue = current;
                }
            }
            catch (HttpRequestException ex)
            {
                // Network error (offline, DNS failure, connection refused, etc.)
                // Keep RetryCount at 0 so items retry indefinitely until the server
                // is reachable again – never mark as Failed for connectivity issues.
                _logger.LogWarning("Sync batch failed (network) – will keep retrying. {Message}", ex.Message);
                foreach (var item in pending)
                {
                    item.SyncState  = SyncState.PendingSync;
                    item.RetryCount = 0;   // reset so we never hit the retry limit
                    item.SyncError  = "Offline – retrying…";
                }
            }
            catch (Exception ex)
            {
                // Non-network error (server 4xx/5xx, bad payload, etc.)
                // Apply retry limit – after MaxRetries mark as Failed so the user
                // knows manual intervention is needed.
                _logger.LogWarning(ex, "Sync batch failed (server error) – {Message}", ex.Message);
                foreach (var item in pending)
                {
                    item.RetryCount++;
                    item.SyncError = ex.Message;
                    if (item.RetryCount >= MaxRetries)
                    {
                        item.SyncState = SyncState.Failed;
                        _logger.LogError("Entry {RequestId} exhausted retries – manual action needed.", item.RequestId);
                    }
                    else
                    {
                        item.SyncState = SyncState.PendingSync;
                    }
                }
            }
            finally
            {
                // Keep only unsynced items in the queue (prune synced ones after 24 h)
                var pruned = queue
                    .Where(e => e.SyncState != SyncState.Synced ||
                                e.OccurredAt > DateTimeOffset.UtcNow.AddHours(-24))
                    .ToList();

                await SaveQueueAsync(pruned);
                QueueChanged?.Invoke();
            }
        }
        finally
        {
            _queueLock.Release();
        }
    }

    public async Task<int> GetPendingCountAsync()
    {
        var q = await GetQueueInternalAsync();
        // Count both PendingSync and orphaned Syncing items so the nav badge
        // stays accurate even when FlushAsync is mid-flight or was interrupted.
        return q.Count(e => e.SyncState == SyncState.PendingSync || e.SyncState == SyncState.Syncing);
    }

    /// <summary>
    /// Pull recent server-side entries for the current user and merge them
    /// into the persisted queue so the UI shows the latest server records.
    /// This is called on connectivity restore to ensure multi-user updates
    /// propagate to online clients.
    /// </summary>
    public async Task PullServerEntriesAsync()
    {
        if (!_connectivity.IsOnline) return;
        // Fetch server rows for this franchisee/user since the last known sync.
        var last = await GetLastSyncedAtAsync();
        var serverList = await _api.GetActivityLogsAsync(_userId, last);
        if (serverList == null) return;

        await _queueLock.WaitAsync();
        try
        {
            var queue = await GetQueueInternalAsync();

            DateTimeOffset? maxSynced = last;
            foreach (var dto in serverList)
            {
                var existing = queue.FirstOrDefault(q => q.RequestId == dto.RequestId);
                if (existing is not null)
                {
                    // Ensure server id and synced state are set
                    existing.ServerId = dto.Id;
                    existing.SyncState = SyncState.Synced;
                    existing.SyncError = null;
                }
                else
                {
                    // Add server record so the UI shows it alongside local entries.
                    queue.Add(new ActivityLogEntry
                    {
                        RequestId = dto.RequestId,
                        FranchiseeId = dto.FranchiseeId,
                        ActivityType = dto.ActivityType,
                        Notes = dto.Notes,
                        PhReading = dto.PhReading,
                        TemperatureCelsius = dto.TemperatureCelsius,
                        OccurredAt = dto.OccurredAt,
                        SyncState = SyncState.Synced,
                        ServerId = dto.Id
                    });
                }
                if (dto.SyncedAt != default)
                {
                    if (!maxSynced.HasValue || dto.SyncedAt > maxSynced.Value)
                        maxSynced = dto.SyncedAt;
                }
            }

            // Persist merged queue
            await SaveQueueAsync(queue);
            QueueChanged?.Invoke();
            // Persist LastSyncedAt so next reconnect uses incremental pulls.
            if (maxSynced.HasValue)
            {
                await SaveLastSyncedAtAsync(maxSynced.Value);
            }
        }
        finally
        {
            _queueLock.Release();
        }
    }

    private Task<DateTimeOffset?> GetLastSyncedAtAsync()
        => _storage.GetItemAsync<DateTimeOffset?>(LastSyncedKey);

    private Task SaveLastSyncedAtAsync(DateTimeOffset when)
        => _storage.SetItemAsync<DateTimeOffset?>(LastSyncedKey, when);

    public void Dispose() => _retryTimer.Dispose();

    // ---- private helpers ----

    private async Task<List<ActivityLogEntry>> GetQueueInternalAsync()
    {
        try
        {
            return await _storage.GetItemAsync<List<ActivityLogEntry>>(QueueKey) ?? new();
        }
        catch
        {
            return new();
        }
    }

    private Task SaveQueueAsync(IEnumerable<ActivityLogEntry> queue)
        => _storage.SetItemAsync(QueueKey, queue.ToList());
}
