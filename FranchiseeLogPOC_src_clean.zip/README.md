# FranchiseeLogPOC

**Single POC solution** demonstrating all four capability areas for the Franchisee Log application.

---

## Solution Structure

```
FranchiseeLogPOC/
├── FranchiseeLogPocClient/
│   └── FranchiseeLogPOC.Client/     Blazor WebAssembly PWA
├── FranchiseeLogPocApi/
│   └── FranchiseeLogPOC.Api/        ASP.NET Core 9 Web API
└── docs/                            documentation and scripts
```

---

## Stack Assessment ✅

| Requirement | Approach | Verdict |
|---|---|---|
| **Offline mode + sync** | Blazor WASM PWA · LocalStorage queue · Idempotent batch sync API | ✅ Valid |
| **Bluetooth sensors** | Web Bluetooth API (JS interop) · Chrome/Edge/Android Chrome | ✅ Valid — not supported in Safari/iOS browser |
| **Push notifications** | Web Push API · Service Worker · VAPID | ✅ Valid — iOS requires PWA installed to home screen (16.4+) |
| **Mobile + PC UI** | MudBlazor 9 (Material Design, fully responsive) | ✅ Valid |
| **Auth** | Entra ID / Azure AD · MSAL.js (client) · Microsoft.Identity.Web (API) | ✅ Valid |
| **Sync pattern** | Client RequestId GUID · Idempotent `/sync` endpoint · LocalStorage retry queue | ✅ Valid |
| **Permanent DB** | SQL Server + EF Core 9 | ✅ Valid |

---

## POC Features Demonstrated

### 1 · Offline Sync
- Every `ActivityLogEntry` gets a client-generated `RequestId` (GUID).
- When **offline**: entries are saved to `LocalStorage` with `SyncState = PendingSync`.
- When **online**: a batch `POST /api/activitylogs/sync` is called.
- The API is **idempotent** – duplicate `RequestId`s return the existing record without inserting a duplicate.
- Connectivity banner in the app bar shows online/offline state and pending count.

### 2 · Bluetooth Sensor Integration (Phase 2)
- `wwwroot/js/bluetooth.js` wraps the **Web Bluetooth API**.
- Connects to BLE devices exposing the **Environmental Sensing Service (UUID 0x181A)**.
- Reads **pH** (custom UUID – replace with your sensor's UUID) and **Temperature** (standard 0x2A6E).
- Readings can be pasted directly into the Activity Log form.
- Page: `/bluetooth`

### 3 · Push / Browser Notifications (Phase 2)
- `wwwroot/js/push-notifications.js` wraps the **Push API** + **Notification API**.
- Service worker (`service-worker.published.js`) handles incoming push payloads and notification clicks.
- `PushSubscriptionsController` stores subscriptions in SQL Server.
- `POST /api/pushsubscriptions/trigger-demo` demonstrates the server-push trigger.
- For production delivery: add a **WebPush** NuGet package and implement VAPID signing.
- Page: `/notifications`

### 4 · Responsive Mobile + PC UI
- **MudBlazor 9** — Material Design components, drawer navigation, responsive grid.
- App bar shows connectivity badge and logged-in user name.
- Pages tested at mobile (360 px), tablet (768 px) and desktop (1920 px).

---

## Setup Guide

### Prerequisites
- .NET 9 SDK
- SQL Server (any edition / LocalDB)
- An Azure AD / Entra ID tenant with two App Registrations (API + Client)

### 1 · Azure AD App Registrations

#### API App Registration
1. New registration → single-tenant.
2. Expose an API → Add a scope: `access_as_user`.
3. Note **Application (client) ID** → use as `AzureAd:ClientId` in `appsettings.json`.

#### Client App Registration
1. New registration → **Single-page application** platform → redirect URI:
   `https://localhost:7001/authentication/login-callback`
2. Add a **logout URL**: `https://localhost:7001/authentication/logout-callback`
3. Under **API permissions** → add your API scope (`api://<api-client-id>/access_as_user`).
4. Note **Application (client) ID** → use as `AzureAd:ClientId` in `wwwroot/appsettings.json`.

### 2 · API — appsettings.json

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=.;Database=FranchiseeLogPOC;Trusted_Connection=True;TrustServerCertificate=True;"
  },
  "AzureAd": {
    "Instance":  "https://login.microsoftonline.com/",
    "Domain":    "yourdomain.onmicrosoft.com",
    "TenantId":  "<your-tenant-id>",
    "ClientId":  "<api-app-registration-client-id>",
    "Scopes":    "access_as_user"
  },
  "ClientOrigin": "https://localhost:7001"
}
```

### 3 · Client — wwwroot/appsettings.json

```json
{
  "AzureAd": {
    "Authority":         "https://login.microsoftonline.com/<your-tenant-id>",
    "ClientId":          "<client-app-registration-client-id>",
    "ValidateAuthority": true
  },
  "ApiScope":      "api://<api-client-id>/access_as_user",
  "ApiBaseUrl":    "https://localhost:7000/",
  "VapidPublicKey": "<your-vapid-public-key>"
}
```

---

### Quick Dev setup & Entra notes

-- Keep `UseDevAuth` = `true` in `FranchiseeLogPocClient/FranchiseeLogPOC.Client/wwwroot/appsettings.json` while you verify app registrations. This activates the development fake user (Dev User) and allows quick local testing without Entra.
- Which ID to use: always use the **Application (client) ID** (the GUID shown in App Registrations). Do NOT use the object id. Use the SPA app's ClientId for the client and the API app's ClientId for the API (and as the exposed scope identifier).
- Redirect / logout URLs must match exactly (including port). If your SPA runs on `https://localhost:7001`, register exactly:

  - `https://localhost:7001/authentication/login-callback`
  - `https://localhost:7001/authentication/logout-callback`

- If you later set `UseDevAuth=false`:
  1. Put the SPA ClientId into `src/FranchiseeLogPOC.Client/wwwroot/appsettings.json` → `AzureAd:ClientId`.
  2. Put the API ClientId (or Tenant & API settings) into `src/FranchiseeLogPOC.Api/appsettings.json` → `AzureAd` section and configure the scope the API exposes.

- Ports matter for the redirect URIs only — register whatever port you run the SPA on locally. The API port does not need to be registered as a redirect URI, but the SPA's `ApiScope` must point to the API app's scope value.

- Dev sign-in / sign-out: while `UseDevAuth=true` the top bar Sign in / Log out buttons will toggle the dev user. Sign out clears the dev user (anonymous) and the offline queue namespace switches to `anonymous`.


### 4 · Run

```powershell
# Terminal 1 – API
cd FranchiseeLogPocApi\FranchiseeLogPOC.Api
dotnet run

# Terminal 2 – Blazor Client
cd FranchiseeLogPocClient\FranchiseeLogPOC.Client
dotnet run
```

> The API auto-applies EF migrations on startup. No manual `dotnet ef database update` needed for the POC.

### 5 · VAPID Keys (for push notifications)

Generate a VAPID key pair:
```bash
npx web-push generate-vapid-keys
```
Copy the **public key** into `VapidPublicKey` in the client appsettings.
Store the **private key** securely in the API (user secrets / Key Vault in production).

---

## Key Files

| File | Purpose |
|---|---|
| `Api/Controllers/ActivityLogsController.cs` | Idempotent single + batch sync endpoints |
| `Api/Controllers/ScheduledEventsController.cs` | CRUD for scheduled events |
| `Api/Controllers/PushSubscriptionsController.cs` | Push subscription storage + demo trigger |
| `Api/Data/AppDbContext.cs` | EF Core DbContext with seed data |
| `Client/Services/OfflineSyncService.cs` | Offline queue, retry, auto-flush |
| `Client/Services/ConnectivityService.cs` | Online/offline JS interop |
| `Client/Services/BluetoothService.cs` | Web Bluetooth JS interop |
| `Client/Services/PushNotificationService.cs` | Web Push JS interop |
| `Client/wwwroot/js/connectivity-interop.js` | Browser online/offline events |
| `Client/wwwroot/js/bluetooth.js` | Web Bluetooth API wrapper |
| `Client/wwwroot/js/push-notifications.js` | Push API + Notification API wrapper |
| `Client/wwwroot/service-worker.published.js` | PWA service worker + push handlers |
| `Client/Pages/ActivityLog.razor` | Main offline-capable log form |
| `Client/Pages/BluetoothDemo.razor` | Phase 2: Bluetooth demo page |
| `Client/Pages/NotificationsDemo.razor` | Phase 2: Push notifications demo page |

---

## Production Upgrade Notes

| Area | POC approach | Production recommendation |
|---|---|---|
| **Offline storage** | `Blazored.LocalStorage` | Use **IndexedDB** (via `wwwroot/js/offline-db.js` scaffold) for larger datasets |
| **Sync conflict** | Last-write-wins | Add server-side conflict detection + user review queue |
| **Push delivery** | Stub trigger endpoint | Add **WebPush** NuGet package + VAPID signing + reliable scheduler (Hangfire/Azure Functions) |
| **Retry** | In-memory exponential back-off | Persist retry state; use background sync via Service Worker Background Sync API |
| **Auth** | MSAL PKCE | Already production-ready with Entra ID |
| **Migrations** | Auto-applied on startup | Use CI pipeline / separate migration step |
