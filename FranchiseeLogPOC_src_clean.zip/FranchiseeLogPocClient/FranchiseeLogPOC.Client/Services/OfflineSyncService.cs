using Blazored.LocalStorage;
using FranchiseeLogPOC.Client.Models;

namespace FranchiseeLogPOC.Client.Services;

/// <summary>
/// Manages the offline activity-log queue.
///
/// Pattern:
///   1. Every entry is saved to LocalStorage with SyncState = PendingSync.
///   2. If online, an immediate sync attempt is made right away.
///   3. When connectivity changes to online, all pending items are flushed.
///   4. A 30-second polling timer retries pending items regardless of browser
///      online/offline events (navigator.onLine is unreliable on Windows when
///      WiFi drops but other network adapters remain present).
///   5. Retry with exponential back-off (max 5 attempts).
/// </summary>
public class OfflineSyncService : IDisposable
{
    // Queue key is namespaced per user so two users on the same device
    // never share or overwrite each other's offline queue.
    private string QueueKey => $"offline_activity_queue_{_userId}";
    private const int MaxRetries = 5;
    private static readonly TimeSpan RetryInterval = TimeSpan.FromSeconds(30);

    private readonly ILocalStorageService _storage;
    private readonly IApiClient _api;
    private readonly ConnectivityService _connectivity;
    private readonly ILogger<OfflineSyncService> _logger;
    private readonly Timer _retryTimer;
    private string _userId = "anonymous";  // set via SetUser() before first use

    public event Action? QueueChanged;

    /// <summary>
    /// Call this once after authentication resolves so the queue is namespaced
    /// to the logged-in user. Prevents queue bleed between users on shared devices.
    /// </summary>
    public void SetUser(string userId)
    {
        _userId = string.IsNullOrWhiteSpace(userId) ? "anonymous" : userId;
    }

    public OfflineSyncService(
        ILocalStorageService storage,
        IApiClient api,
        ConnectivityService connectivity,
        ILogger<OfflineSyncService> logger)
    {
        _storage = storage;
        _api = api;
        _connectivity = connectivity;
        _logger = logger;

        // Subscribe to browser online/offline events (best-effort – unreliable on Windows)
        _connectivity.ConnectivityChanged += async online =>
        {
            if (online)
            {
                _logger.LogInformation("Connectivity restored – flushing offline queue.");
                await FlushAsync();
            }
        };

        // Polling fallback: retry every 30 s regardless of browser events.
        // Initial delay is 5 s so items queued while online get a quick first attempt.
        _retryTimer = new Timer(async _ =>
        {
            var pending = await GetPendingCountAsync();
            if (pending > 0)
            {
                _logger.LogInformation("Retry timer: {Count} pending items – attempting sync.", pending);
                await FlushAsync();
            }
        }, null, TimeSpan.FromSeconds(5), RetryInterval);
    }

    /// <summary>
    /// Adds an entry to the local queue and immediately tries to sync if online.
    /// </summary>
    public async Task EnqueueAsync(ActivityLogEntry entry)
    {
        var queue = await GetQueueInternalAsync();
        entry.SyncState = SyncState.PendingSync;
        queue.Add(entry);
        await SaveQueueAsync(queue);
        QueueChanged?.Invoke();
        // Do NOT attempt an immediate flush here – the 5-second timer handles
        // the first attempt. This avoids the visible Syncing→Pending flash when
        // the device thinks it's online but the API is unreachable.
    }

    /// <summary>
    /// Try to save the provided entry immediately to the API while
    /// still keeping a local copy so it can be retried if connectivity
    /// drops mid-flight.
    /// Returns true if the server accepted the entry; otherwise false
    /// and the entry is left in the local queue for retry.
    /// </summary>
    public async Task<bool> TrySaveNowAsync(ActivityLogEntry entry)
    {
        // Add to local queue first so the UI shows the entry immediately.
        var queue = await GetQueueInternalAsync();
        entry.SyncState = SyncState.Syncing;
        entry.RetryCount = 0;
        queue.Add(entry);
        await SaveQueueAsync(queue);
        QueueChanged?.Invoke();

        if (!_connectivity.IsOnline)
        {
            // Not online — ensure Pending and return false so caller knows it wasn't shipped.
            entry.SyncState = SyncState.PendingSync;
            entry.SyncError = "Offline – will retry";
            await SaveQueueAsync(queue);
            QueueChanged?.Invoke();
            return false;
        }

        try
        {
            var batch = new SyncBatchRequest
            {
                Items = new List<SyncItem>
                {
                    new SyncItem
                    {
                        RequestId = entry.RequestId,
                        FranchiseeId = entry.FranchiseeId,
                        ActivityType = entry.ActivityType,
                        Notes = entry.Notes,
                        PhReading = entry.PhReading,
                        TemperatureCelsius = entry.TemperatureCelsius,
                        OccurredAt = entry.OccurredAt
                    }
                }
            };

            var response = await _api.SyncBatchAsync(batch);
            if (response is not null && response.Results.Any())
            {
                var result = response.Results.First();
                var q = await GetQueueInternalAsync();
                var saved = q.FirstOrDefault(e => e.RequestId == result.RequestId);
                if (saved is not null)
                {
                    saved.SyncState = SyncState.Synced;
                    saved.ServerId = result.ServerId;
                    saved.SyncError = null;
                    await SaveQueueAsync(q);
                    QueueChanged?.Invoke();
                }

                return true;
            }

            // Server didn't return a result – keep for retry.
            entry.SyncState = SyncState.PendingSync;
            entry.SyncError = "Server did not accept entry";
            await SaveQueueAsync(queue);
            QueueChanged?.Invoke();
            return false;
        }
        catch (HttpRequestException ex)
        {
            // Network dropped mid-flight – keep for retry.
            _logger.LogWarning("TrySaveNow failed (network): {Message}", ex.Message);
            entry.SyncState = SyncState.PendingSync;
            entry.RetryCount = 0;
            entry.SyncError = "Offline – will retry";
            await SaveQueueAsync(queue);
            QueueChanged?.Invoke();
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "TrySaveNow failed (server error): {Message}", ex.Message);
            entry.SyncState = SyncState.PendingSync;
            entry.RetryCount++;
            entry.SyncError = ex.Message;
            await SaveQueueAsync(queue);
            QueueChanged?.Invoke();
            return false;
        }
    }

    /// <summary>
    /// Returns a read-only snapshot of the current queue.
    /// </summary>
    public async Task<IReadOnlyList<ActivityLogEntry>> GetQueueAsync()
        => await GetQueueInternalAsync();

    /// <summary>
    /// Pushes all pending items to the API in a single batch call.
    /// Items that successfully sync are removed from the queue.
    /// </summary>
    public async Task FlushAsync()
    {
        var queue = await GetQueueInternalAsync();

        // Reset any orphaned "Syncing" items – these occur when the app refreshed
        // or WiFi dropped mid-flight before the catch block could run.
        foreach (var stuck in queue.Where(e => e.SyncState == SyncState.Syncing))
            stuck.SyncState = SyncState.PendingSync;

        var pending = queue.Where(e => e.SyncState == SyncState.PendingSync && e.RetryCount < MaxRetries).ToList();

        if (pending.Count == 0) return;

        _logger.LogInformation("Flushing {Count} offline entries.", pending.Count);

        foreach (var item in pending)
            item.SyncState = SyncState.Syncing;

        await SaveQueueAsync(queue);
        QueueChanged?.Invoke();

        try
        {
            var batch = new SyncBatchRequest
            {
                Items = pending.Select(e => new SyncItem
                {
                    RequestId          = e.RequestId,
                    FranchiseeId       = e.FranchiseeId,
                    ActivityType       = e.ActivityType,
                    Notes              = e.Notes,
                    PhReading          = e.PhReading,
                    TemperatureCelsius = e.TemperatureCelsius,
                    OccurredAt         = e.OccurredAt
                }).ToList()
            };

            var response = await _api.SyncBatchAsync(batch);

            if (response is not null)
            {
                foreach (var result in response.Results)
                {
                    var entry = queue.FirstOrDefault(e => e.RequestId == result.RequestId);
                    if (entry is not null)
                    {
                        entry.SyncState = SyncState.Synced;
                        entry.ServerId  = result.ServerId;
                        entry.SyncError = null;
                    }
                }
            }
        }
        catch (HttpRequestException ex)
        {
            // Network error (offline, DNS failure, connection refused, etc.)
            // Keep RetryCount at 0 so items retry indefinitely until the server
            // is reachable again – never mark as Failed for connectivity issues.
            _logger.LogWarning("Sync batch failed (network) – will keep retrying. {Message}", ex.Message);
            foreach (var item in pending)
            {
                item.SyncState  = SyncState.PendingSync;
                item.RetryCount = 0;   // reset so we never hit the retry limit
                item.SyncError  = "Offline – retrying…";
            }
        }
        catch (Exception ex)
        {
            // Non-network error (server 4xx/5xx, bad payload, etc.)
            // Apply retry limit – after MaxRetries mark as Failed so the user
            // knows manual intervention is needed.
            _logger.LogWarning(ex, "Sync batch failed (server error) – {Message}", ex.Message);
            foreach (var item in pending)
            {
                item.RetryCount++;
                item.SyncError = ex.Message;
                if (item.RetryCount >= MaxRetries)
                {
                    item.SyncState = SyncState.Failed;
                    _logger.LogError("Entry {RequestId} exhausted retries – manual action needed.", item.RequestId);
                }
                else
                {
                    item.SyncState = SyncState.PendingSync;
                }
            }
        }
        finally
        {
            // Keep only unsynced items in the queue (prune synced ones after 24 h)
            var pruned = queue
                .Where(e => e.SyncState != SyncState.Synced ||
                            e.OccurredAt > DateTimeOffset.UtcNow.AddHours(-24))
                .ToList();

            await SaveQueueAsync(pruned);
            QueueChanged?.Invoke();
        }
    }

    public async Task<int> GetPendingCountAsync()
    {
        var q = await GetQueueInternalAsync();
        // Count both PendingSync and orphaned Syncing items so the nav badge
        // stays accurate even when FlushAsync is mid-flight or was interrupted.
        return q.Count(e => e.SyncState == SyncState.PendingSync || e.SyncState == SyncState.Syncing);
    }

    public void Dispose() => _retryTimer.Dispose();

    // ---- private helpers ----

    private async Task<List<ActivityLogEntry>> GetQueueInternalAsync()
    {
        try
        {
            return await _storage.GetItemAsync<List<ActivityLogEntry>>(QueueKey) ?? new();
        }
        catch
        {
            return new();
        }
    }

    private Task SaveQueueAsync(IEnumerable<ActivityLogEntry> queue)
        => _storage.SetItemAsync(QueueKey, queue.ToList()).AsTask();
}
