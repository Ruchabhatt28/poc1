using FranchiseeLogPOC.Client.Models;
using System.Net.Http.Json;

namespace FranchiseeLogPOC.Client.Services;

/// <summary>API client contract for dependency injection / testing.</summary>
public interface IApiClient
{
    Task<SyncBatchResponse?> SyncBatchAsync(SyncBatchRequest request, CancellationToken ct = default);
}

public class ApiClient(HttpClient http) : IApiClient
{
    public async Task<SyncBatchResponse?> SyncBatchAsync(SyncBatchRequest request, CancellationToken ct = default)
    {
        var response = await http.PostAsJsonAsync("api/activitylogs/sync", request, ct);
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<SyncBatchResponse>(cancellationToken: ct);
    }
}

// ---- Shared request/response DTOs ----
public class SyncBatchRequest
{
    public List<SyncItem> Items { get; set; } = new();
}

public class SyncItem
{
    public Guid RequestId { get; set; }
    public string FranchiseeId { get; set; } = string.Empty;
    public string ActivityType { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public double? PhReading { get; set; }
    public double? TemperatureCelsius { get; set; }
    public DateTimeOffset OccurredAt { get; set; }
}

public class SyncBatchResponse
{
    public List<SyncItemResult> Results { get; set; } = new();
    public int Accepted { get; set; }
    public int Duplicate { get; set; }
}

public class SyncItemResult
{
    public Guid RequestId { get; set; }
    public bool WasDuplicate { get; set; }
    public int ServerId { get; set; }
}


